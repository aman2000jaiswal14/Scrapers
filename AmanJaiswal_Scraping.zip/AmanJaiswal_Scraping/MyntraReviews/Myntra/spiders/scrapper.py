import scrapy
import re
import math
from scrapy.utils.project import get_project_settings
from twisted.internet import reactor
from scrapy.utils.log import configure_logging
from scrapy.crawler import CrawlerRunner

import pandas as pd
import json
# from scraper_api import ScraperAPIClient
from scrapy.crawler import CrawlerProcess
df = pd.read_csv('myntra_tops.csv')
df = df.head(100)
df['ReviewCount'] = [None for i in range(df.shape[0])]
df['ImageCount'] = [None for i in range(df.shape[0])]
global total
total = 0
base = "https://www.myntra.com/gateway/v1/reviews/product/13719116?size=12&sort=0&rating=0&page=1&includeMetaData=true&__amp_source_origin=https%3A%2F%2Fwww.myntra.com"
class Spider1(scrapy.Spider):
    name = 'scrapper1'
    start_urls = ["https://www.myntra.com/web/v2/search/women-sportswear-clothing?p=1&plaEnabled=false&rows=50&o=0"]
    def parse(self,response):
        # url = "https://www.myntra.com/gateway/v1/reviews/product/13719116?size=12&sort=0&rating=0&page=1&includeMetaData=True&__amp_source_origin=https%3A%2F%2Fwww.myntra.com"
        base = "https://www.myntra.com/gateway/v1/reviews/product/{}?size=12&sort=0&rating=0&page=1&includeMetaData=true"
        for i in range(df.shape[0]):
            print(i,'-'*100)
            url = base.format(df['productId'][i])
            # url = 'https://www.myntra.com/gateway/v1/reviews/product/13532724?size=12&sort=0&rating=0&page=2&includeMetaData=true'
            yield scrapy.Request(url=url, callback=self.parse1,meta={'idd':i})
    # def start_requests(self):
    #     url = base.format('13719116')
    #     yield scrapy.Request(url=url, callback=self.parse)

    def parse1(self,response):
        print(response.status)
        print("in the parse")
        # print(response.text)
        jd = json.loads(response.text)
        idd = response.meta['idd']
        # print(jd['reviewsMetaData'])
        df['ReviewCount'][idd] = jd['reviewsMetaData']['reviewCount']
        df['ImageCount'][idd] = jd['reviewsMetaData']['imageCount']
        global total
        total+=1
        if(total%5000==0):
            df.to_csv('myntra_tops{}.csv'.format(total),index=False)
        yield {'idd':idd}
process = CrawlerProcess()
process.crawl(Spider1)
process.start()
# print(df)

# df.to_csv('temp.csv',index=False)







# configure_logging()
# runner = CrawlerRunner(get_project_settings())
# runner.crawl(Spider1)
# d = runner.join()
# d.addBoth(lambda _: reactor.stop())
# reactor.run()
'''
client = ScraperAPIClient('')
df = pd.read_csv('myntra_tops.csv')
df = df.head(5)
df['ReviewCount'] = [None for i in range(df.shape[0])]
df['ImageCount'] = [None for i in range(df.shape[0])]

class ScrapperSpider(scrapy.Spider):
    name = 'scrapper1'
    base_url  ='https://www.myntra.com/gateway/v1/reviews/product/{}?size=12&sort=0&rating=0&page=200&includeMetaData=true&'
    # base_url = 'https://www.myntra.com/gateway/v1/reviews/product/13532724?size=50&sort=0&rating=0&page=1&includeMetaData=true&p=3&plaEnabled=false&rows=50&o=0'
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'deviceId': 'fdd8f6e7-c028-409a-b936-6021d5ff4ea7',
        'Referer': 'https://www.myntra.com/reviews/13719116',
        'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
        'sec-ch-ua-mobile': '?0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
        'x-location-context': 'pincode=700006;source=IP',
        'x-meta-app': 'deviceId=fdd8f6e7-c028-409a-b936-6021d5ff4ea7;appFamily=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36;reqChannel=web;',
        'X-myntraweb': 'Yes',
        'X-Requested-With': 'browser',
        'X-Sec-Clge-Req-Type': 'ajax'
    }

    def start_requests(self):
        url = self.base_url.format(df['productId'][0])

        yield scrapy.Request(client.scrapyGet(url = url), headers=self.headers, callback=self.goto_prod)

        # for i in range(df.shape[0]):
            # url = self.base_url.format(df['productId'][i])
            # url = self.base_url
            # print(url)
            # yield scrapy.Request(url=url, headers=self.headers, callback=self.goto_prod,meta={'idd':i})


    def goto_prod(self, response):
        print(response.status)
        print("no")
        print(response.text)
        # jd = json.loads(response.text)
        # idd = response.meta['idd']
        # df['ReviewCount'][idd] = jd['reviewsMetaData']['reviewCount']
        # df['ImageCount'][idd] = jd['reviewsMetaData']['imageCount']
        # yield {'idd':idd}
process = CrawlerProcess()
process.crawl(ScrapperSpider)
process.start()

# df.to_csv('temp.csv',index=False)
'''