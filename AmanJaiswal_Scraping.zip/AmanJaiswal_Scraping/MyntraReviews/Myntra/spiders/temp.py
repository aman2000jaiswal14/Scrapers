# import requests
# print('start')
# url = 'https://www.myntra.com/gateway/v1/reviews/product/13532724?size=12&sort=0&rating=0&page=2&includeMetaData=true'
# req = requests.get(url)
# print('hello')
# print(req.status_code)
#
# import http.client,urllib.parse
# params = urllib.parse.urlencode({'size': 12, 'sort': 0, 'ratings':0,'page':1,'includeMetaData':True})
# headers = {  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'}
#
# conn = http.client.HTTPSConnection("www.myntra.com/gateway/v1/reviews/product/13532724")
#
# conn.request("GET", "",params,headers)
# r1 = conn.getresponse()
# print(r1.status, r1.reason)
import json
import pandas as pd
df = pd.read_csv('revdf1.csv')
print(df.head())
for num,i in enumerate(df['rev']):
    print(num,df['ReviewCount'][num],df['productId'][num])
    jd = json.loads(i)

    print(type(jd))

    print(len(jd))
    try:
        print(jd[0]['images'][0]['url'])
    except:
        pass
    print()