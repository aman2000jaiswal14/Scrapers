import scrapy
import re
import math
import numpy as np
from scrapy.utils.project import get_project_settings
from twisted.internet import reactor
from scrapy.utils.log import configure_logging
from scrapy.crawler import CrawlerRunner

import pandas as pd
import json
from scrapy.crawler import CrawlerProcess
TOTAL = 0
PRODUCT = 0
totalset = set()
df = pd.read_csv('myntra_tops_rev_count.csv')
# df = df.head(20)
df = df.tail(10)
df['rev'] = [[] for i in range(df.shape[0])]

class Spider2(scrapy.Spider):
    name = 'scrapper2'
    start_urls = ["https://www.myntra.com/web/v2/search/women-sportswear-clothing?p=1&plaEnabled=false&rows=50&o=0"]
    def parse(self,response):
        base = "https://www.myntra.com/gateway/v1/reviews/product/{}?size=12&sort=0&rating=0&page={}&includeMetaData=true"

        for i in df.index:
            rc,ic =0,0
            if(not np.isnan(df['ReviewCount'][i])):
                rc = df['ReviewCount'][i]
            if(not np.isnan(df['ImageCount'][i])):
                ic = df['ImageCount'][i]
            print(rc,ic)

            PAGES = math.ceil(( rc+ ic) / 12) + 5
            P1 = 1
            if(PAGES==5):
                PAGES = 60
            print('TOTAL PAGES : ',PAGES)
            for page in range(1,PAGES+1):
                if(page>0):
                    P1 = 0
                print('PRODUCT : ',i,"  PAGE : ",page, '-' * 100,P1)
                url = base.format(df['productId'][i],page)
                res = scrapy.Request(url=url, callback=self.parse1,meta={'idd':i,'p1':P1})
                yield res
            print(i,ic,rc,PAGES,df['productId'][i])


    def parse1(self,response):
        # print(response.status)
        # print("in the parse")
        jd = json.loads(response.text)
        idd = response.meta['idd']
        p1 = response.meta['p1']
        # revjd = json.loads(df['rev'][idd])
        revjd = df['rev'][idd]
        for rev in jd['reviews']:

            revjd.append(rev)
        # df['rev'][idd] = json.dumps(revjd)

        global PRODUCT,TOTAL,totalset
        TOTAL+=1
        totalset.add(idd)
        PRODUCT = len(totalset)
        print("Success : ",idd,"   Total pages traverse : " , TOTAL,"     PRODUCT  : ",PRODUCT)

process = CrawlerProcess()
process.crawl(Spider2)
process.start()

for i in df.index:
    df['rev'][i] = json.dumps(df['rev'][i])
df.to_csv('revdf1.csv',index=False)

