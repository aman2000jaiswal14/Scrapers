import sys
import scrapy
import json
import math
import re
sys.path.insert(1, r'C:\Users\aman2\Desktop\Artyvis\Scraping\utils')
from write_data_utils import WriteData
from prev_index_utils import get_start_index,set_start_index
from scrapy.utils.project import get_project_settings
from twisted.internet import reactor
from scrapy.crawler import CrawlerRunner
from scrapy.utils.log import configure_logging
from datetime import datetime


source = 'Myntra'
category = 'Kids'
subcategory = 'Accessories'
FILENAME = source+'_'+category+'_'+subcategory+'_'+(str(datetime.now())).replace(':','-').replace('.','-')
wd = WriteData(FILENAME,source,category,subcategory)


base = "https://www.myntra.com/web/v2/search/{}?p={}&plaEnabled=false&rows=50&o={}"
Myntraid = get_start_index(source)

def cleanup(string):
    string = re.sub("[<p>]", "", string)
    return string
def cleanhtml(raw_html):
  cleanr = re.compile('<.*?>')
  cleantext = re.sub(cleanr, '', raw_html)
  return cleantext


def parse_info_help(response):
    global Myntraid
    jd = json.loads(response.text)[0]['style']
    data = {}
    try:
        data['source'] = 'Myntra'
    except:
        data['source'] = 'Myntra'

    try:
        data['Native_product_id'] = jd['id']
    except:
        data['Native_product_id'] = None

    data['product_id'] = Myntraid
    Myntraid+=1


    try:
        data['Category'] = jd['analytics']['gender']
    except:
        data['Category'] = 'Women'

    try:
        data['Subcategory1'] = jd['analytics']['subCategory']
    except:
        data['Subcategory1'] = None

    try:
        data['Subcategory2'] = jd['analytics']['masterCategory']
    except:
        data['Subcategory2'] = None

    try:
        data['Subcategory3'] = jd['analytics']['articleType']
    except:
        data['Subcategory3'] = None


    try:
        data['Title'] = jd['name']
    except:
        data['Title'] = None

    try:
        data['Brand'] = jd['brand']['name']
    except:
        data['Brand'] = None

    try:
        data['Item_url'] = response.meta['item_url']
    except:
        data['Item_url'] = None

    try:
        data['currentPrice'] = jd['price']['discounted']
    except:
        data['currentPrice'] = None

    try:
        data['orginalPrice'] = jd['price']['mrp']
    except:
        data['orginalPrice'] = None

    try:
        data['discount'] = jd['price']['discount']['discountPercent']
    except:
        data['discount'] = None

    try:
        data['currencyIso'] = 'INR'
    except:
        data['currencyIso'] = None



    try:
        data['product_detail'] = json.dumps(jd['articleAttributes'])
    except:
        data['product_detail'] = None

    try:
        data['PrimaryColor'] = jd['baseColour']
    except:
        data['PrimaryColor'] = None

    try:
        data['available_colors'] = [color['label'] for color in jd['colours']]
    except:
        data['available_colors'] = None

    try:
        data['CountryOfOrigin'] = jd['countryOfOrigin']
    except:
        data['CountryOfOrigin'] = None
    try:
        data['ManufacturedBy'] = jd['manufacturer']
    except:
        data['ManufacturedBy'] = None


    try:
        data['image_urls'] = json.dumps([img['imageURL'] for img in jd['media']['albums'][0]['images']])
    except:
        data['image_urls'] = json.dumps([])

    try:
        data['sizeTag'] = [size['label'] for size in jd['sizes']]
    except:
        data['sizeTag'] = None

    try:
        data['ExtraSizeDetails'] = json.dumps({size['label']: size['measurements'] for size in jd['sizes']})
    except:
        data['ExtraSizeDetails'] = json.dumps({})

    try:
        data['Description'] = cleanhtml(' '.join([desc['description'] for desc in jd['descriptors']]))
    except:
        data['Description'] = None


    try:
        data['Ratings'] = jd['ratings']['averageRating']
    except:
        data['Ratings'] = None

    try:
        data['Review_counts'] = jd['ratings']['totalCount']
    except:
        data['Review_counts'] = None

    try:
        data['SeasonYear'] = jd['catalogAttributes']['year']
    except:
        data['SeasonYear'] = None

    try:
        data['Season'] = jd['catalogAttributes']['season']
    except:
        data['Season'] = None

    wd.writedata(data)
    # return data
    set_start_index(source,Myntraid)
    return {'success':Myntraid}



class Spider1(scrapy.Spider):
    name = 'kids-accessories'

    start_urls = ["https://www.myntra.com/web/v2/search/{}?p=1&plaEnabled=false&rows=50&o=0".format(name)]

    def parse(self, response):
        data = json.loads(response.text)

        total_item = data['totalCount']
        total_pages = math.ceil(int(total_item) / 50)

        o = 0
        # total_pages=2  ########
        for i in range(1, total_pages + 1):
            next_page = base.format('kids-accessories', i, o)
            o = o + 50
            yield scrapy.Request(url=next_page, callback=self.parse)

        for product in data['products']: ############
            Id = product['productId']
            url = product['landingPageUrl']
            item_url = f'https://www.myntra.com/{url}'
            absolute_url = f"https://www.myntra.com/amp/api/style/{Id}?__amp_source_origin=https%3A%2F%2Fwww.myntra.com"

            yield scrapy.Request(url=absolute_url, callback=self.parse_info, meta={'item_url': item_url})

    def parse_info(self, response):
        result = parse_info_help(response)
        yield result



class Spider2(scrapy.Spider):
    name = 'kids-home-bath'

    start_urls = ["https://www.myntra.com/web/v2/search/{}?p=1&plaEnabled=false&rows=50&o=0".format(name)]

    def parse(self, response):
        data = json.loads(response.text)

        total_item = data['totalCount']
        total_pages = math.ceil(int(total_item) / 50)

        o = 0
        # total_pages=2  ########
        for i in range(1, total_pages + 1):
            next_page = base.format('kids-home-bath', i, o)
            o = o + 50
            yield scrapy.Request(url=next_page, callback=self.parse)

        for product in data['products']: ############
            Id = product['productId']
            url = product['landingPageUrl']
            item_url = f'https://www.myntra.com/{url}'
            absolute_url = f"https://www.myntra.com/amp/api/style/{Id}?__amp_source_origin=https%3A%2F%2Fwww.myntra.com"

            yield scrapy.Request(url=absolute_url, callback=self.parse_info, meta={'item_url': item_url})

    def parse_info(self, response):
        result = parse_info_help(response)
        yield result



configure_logging()

runner = CrawlerRunner(get_project_settings())

runner.crawl(Spider1)

runner.crawl(Spider2)
# runner.crawl(Spider3)
# runner.crawl(Spider4)
# runner.crawl(Spider5)
# runner.crawl(Spider6)
# runner.crawl(Spider7)
d = runner.join()

d.addBoth(lambda _: reactor.stop())

try:
    reactor.run()
except:
    pass
