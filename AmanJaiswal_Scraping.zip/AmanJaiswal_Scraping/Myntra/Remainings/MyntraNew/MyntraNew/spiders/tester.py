# import pandas as pd
# import json
# df1 =  pd.read_excel('Category_Nomenclature.xlsx',sheet_name='women')
# df2 =  pd.read_excel('Category_Nomenclature.xlsx',sheet_name='Men')
# df3 = pd.read_excel('Category_Nomenclature.xlsx',sheet_name='Kids')
# print(df1.shape,df2.shape,df3.shape)
# print(df1.head())
# cat_dict = {}
# tempdict1 = {}
# tempdict2 = {}
# tempdict3 = {}
# for i in range(df1.shape[0]):
#     tempdict1[df1['Sub category 3'][i]] = [df1['Category'][i],df1['Sub category 1'][i],df1['Sub category 2'][i],df1['Sub category 3'][i]]
# cat_dict['women'] = tempdict1
# for i in range(df2.shape[0]):
#     tempdict2[df2['Sub category 3'][i]] = [df2['Category'][i],df2['Sub category 1'][i],df2['Sub category 2'][i],df2['Sub category 3'][i]]
# cat_dict['men'] = tempdict2
# for i in range(df3.shape[0]):
#     tempdict3[df3['Sub category 3'][i]] = [df3['Category'][i],df3['Sub category 1'][i],df3['Sub category 2'][i],df3['Sub category 3'][i]]
# cat_dict['kids'] = tempdict3
# print(cat_dict)
# with open('~$Category_Nomenclature.json','w') as f:
#     json.dump(cat_dict,f,indent=1)
