import os
import csv
import json

class WriteData:
    def __init__(self,filename):
        self.folder = 'DATA'
        self.filename = filename+'.csv'
        self.filepath = os.path.join(self.folder,self.filename)
        self.header = None
        try:
            if(not os.path.exists(self.folder)):
                os.mkdir(self.folder)

            # if(not os.path.exists(self.filepath)):
            #     with open(self.filepath,'w',newline='') as csv_file:
            #         writer = csv.writer(csv_file)
            #         writer.writerow(self.header)
            # else:
            #     if(os.path.getsize(self.filepath)==0):
            #         with open(self.filepath, 'w', newline='') as csv_file:
            #             writer = csv.writer(csv_file)
            #             writer.writerow(self.header)

        except Exception as e:
            print('FAILED TO CREATE FILE TO WRITE DATA .... : ',e)

    def writedata(self,data):
        if((not os.path.exists(self.filepath)) or os.path.getsize(self.filepath)==0):
            self.header = data.keys()
            with open(self.filepath, 'w', newline='') as csv_file:
                writer = csv.writer(csv_file)
                writer.writerow(self.header)
        else:
            try:
                with open(self.filepath, 'a', newline='', encoding='utf-8') as csv_file:
                    writer = csv.DictWriter(csv_file, fieldnames=data.keys())
                    writer.writerow(data)
            except Exception as e:
                print('FAILED TO INSERT DATA INTO FILE .... : ',e)