# import json
#
# def match_categories(jd=None):
#     # catg = jd['analytics']['gender']
#     # catg3 = jd['analytics']['articleType']
#     catg = 'Women'
#     catg3 = 'Sarara'
#     with open('~$Category_Nomenclature.json','r') as f:
#         cat = json.load(f)
#     cat = cat[catg.lower()]
#     cat_keys = cat.keys()
#     if(catg3 in cat):
#         return cat[catg3]
#     get_val = []
#     for key in cat_keys:
#         get_val.append([lcs(key,catg3),catg3,key])
#
#     get_val.sort()
#
#     if(get_val[0][0]==999999999):
#         return [catg,jd['analytics']['masterCategory'],jd['analytics']['subCategory'],catg3]
#     else:
#
#         return cat[get_val[0][2]]
#
#
#
#
# def lcs(s1,s2):
#     s1 = s1.lower()
#     s2 = s2.lower()
#     m, n = len(s1), len(s2)
#     prev, cur = [0]*(n+1), [0]*(n+1)
#     for i in range(1, m+1):
#         for j in range(1, n+1):
#             if s1[i-1] == s2[j-1]:
#                 cur[j] = 1 + prev[j-1]
#             else:
#                 if cur[j-1] > prev[j]:
#                     cur[j] = cur[j-1]
#                 else:
#                     cur[j] = prev[j]
#         cur, prev = prev, cur
#     if(prev[n]<int(len(s2)*(.6))):
#         return 999999999
#     else:
#         return n+m - 2*prev[n]
#
