import scrapy
import re
import json
BASE = 'https://www.limeroad.com'
SEPERATOR = ' ||| '


###
# NOTE
### CHANGE IN GOTOPRODUCT AND GOTOSMILIAR
###

class ScrapperSpider(scrapy.Spider):
    name = 'scrapper'
    base_url = 'https://www.limeroad.com/clothing/westernwear/tops?{}&pageid={}'
    prod_page = 'https://www.limeroad.com/products/'
    category = 'Women'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        TOTALPAGES = 676
        PRICEFILTERS = ['price%5B%5D=0%20TO%20390', 'price%5B%5D=391%20TO%20440', 'price%5B%5D=441%20TO%20499',
                        'price%5B%5D=500%20TO%20590',
                        'price%5B%5D=591%20TO%20650', 'price%5B%5D=651%20TO%20750', 'price%5B%5D=751%20TO%201000',
                        'price%5B%5D=10001%20TO%204999']
        try:
            for filter in PRICEFILTERS:
                try:
                    for page in range(TOTALPAGES):
                        url = self.base_url.format(filter,page)
                        try:
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.goto_page)
                        except Exception as e:
                            print(e)
                            pass
                except Exception as e:
                    print(e)
                    pass
        except Exception as e:
            print(e)
            pass

    def goto_page(self, response):
        product_ids = response.xpath('//img[@class="dB h412 w310 mA pR prdI gtm-p an-ll o0"]/@id').extract()
        try:
            for pid  in product_ids:
                prod_url = self.prod_page+pid
                try:
                    yield scrapy.Request(url=prod_url, headers=self.headers, callback=self.goto_prod,meta = {'url':prod_url,'prod_id':pid})
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)


    def goto_prod(self,response):

        similar = response.css('img::attr(data-c)').extract()
        same = response.meta['prod_id']
        if(len(similar)>0):
            similar = set(similar) - {same}
        for simi in similar:
            prod_url = self.prod_page + simi
            try:
                yield scrapy.Request(url=prod_url, headers=self.headers, callback=self.goto_similiar,
                                     meta={'url': prod_url, 'prod_id': simi})
            except Exception as e:
                print(e)
        prod = {}
        prod['Item_url'] = response.meta['url']
        prod['product_id'] = response.meta['prod_id']
        prod['currencyIso'] = 'INR'

        catg = response.xpath('//span[@itemprop="name"]/text()').extract()
        prod['Category'] = self.category
        prod['Subcategory1'] = catg[2]
        prod['Subcategory2'] = catg[3]

        prod['Title'] = response.xpath('//h1[@class="ftwN m0 p0 c3 fs20 pt0 p12 pb2 bs ttC"]/text()').extract_first()

        prod['Brand'] =response.xpath('//a[@class="fs13 c6 eli pt0 taL tdN ttC hcP"]/span/text()').extract_first()
        if(prod['Brand']==None):
            prod['Brand'] = response.xpath('//a[@class="fs13 c6 eli pt0 taL tdN ttC hcP"]/text()').extract_first()
        prod['Ratings'] = response.xpath('//div[@class="dTc vM fs20 c0"]/text()').extract_first()

        sizetag = response.xpath('//div[@class="br4 dIb m4 vT p12 fs16 bxs bs ttU taC wsN size  bd3 hcP hbxs"]/text()').extract()
        sizetag += response.xpath('//div[@class="br4 dIb m4 vT bxs p12 fs16 bs ttU taC wsN size bd3 sec"]/text()').extract()
        sizetag = [s.strip() for s in sizetag]
        prod['SizeTag'] = sizetag

        sizes = response.xpath('//div[@class="br4 dIb m4 vT p12 fs16 bxs bs ttU taC wsN size  bd3 hcP hbxs"]/@data-k-in').extract()
        sizes = [re.findall('[0-9]+',size) for size in sizes]
        try:
            sizes = ['waist:{} and bust:{}'.format(size[0],size[1]) for size in sizes]
        except:
            try:
                sizes = ['bust:{}'.format(size[0]) for size in sizes]
            except:
                sizes = []
        prod['Sizes'] = sizes

        prod['originalPrice'] = response.xpath('//span[@class="mrp"]/text()').extract_first()
        prod['currentPrice'] = response.xpath('//span[@class="sell"]/text()').extract_first()
        prod['discount'] = response.xpath('//span[@class="per"]/text()').extract_first()

        prod['Wash_Care'] = response.xpath('//div[@class="p80 pt0"]/span/text()').extract_first()

        brand_details = response.xpath('//div[@class="c9 ttL"]/span/text()').extract()
        brand_details = ' '.join(brand_details)
        prod['Brand_Details'] = brand_details

        details_key = response.xpath('//div[@class="dIb vT"]/text()').extract()
        details_val = response.xpath('//div[@class="dIb vT c3"]/text()').extract()
        prod_details = {key:val for key,val in zip(details_key,details_val)}
        prod['product_detail'] = json.dumps(prod_details)

        description = response.xpath('//li[@class="pb6"]/text()').extract()
        description = ' '.join(description)
        prod['Description'] = description

        image_list = response.xpath('//div[@class="m02 vT dIb pR zmimgH w310 h412 z2"]/img/@data-src').extract()
        image_list +=response.xpath('//div[@class="m02 zmimgH vT dIb pR w310 h412 z2"]/img/@data-src').extract()
        prod['image_urls'] = SEPERATOR.join(image_list)



        yield prod

    def goto_similiar(self,response):
        prod = {}
        prod['Item_url'] = response.meta['url']
        prod['product_id'] = response.meta['prod_id']
        prod['currencyIso'] = 'INR'

        catg = response.xpath('//span[@itemprop="name"]/text()').extract()
        prod['Category'] = self.category
        prod['Subcategory1'] = catg[2]
        prod['Subcategory2'] = catg[3]

        prod['Title'] = response.xpath('//h1[@class="ftwN m0 p0 c3 fs20 pt0 p12 pb2 bs ttC"]/text()').extract_first()

        prod['Brand'] = response.xpath('//a[@class="fs13 c6 eli pt0 taL tdN ttC hcP"]/span/text()').extract_first()
        if (prod['Brand'] == None):
            prod['Brand'] = response.xpath('//a[@class="fs13 c6 eli pt0 taL tdN ttC hcP"]/text()').extract_first()
        prod['Ratings'] = response.xpath('//div[@class="dTc vM fs20 c0"]/text()').extract_first()

        sizetag = response.xpath(
            '//div[@class="br4 dIb m4 vT p12 fs16 bxs bs ttU taC wsN size  bd3 hcP hbxs"]/text()').extract()
        sizetag += response.xpath(
            '//div[@class="br4 dIb m4 vT bxs p12 fs16 bs ttU taC wsN size bd3 sec"]/text()').extract()
        sizetag = [s.strip() for s in sizetag]
        prod['SizeTag'] = sizetag

        sizes = response.xpath(
            '//div[@class="br4 dIb m4 vT p12 fs16 bxs bs ttU taC wsN size  bd3 hcP hbxs"]/@data-k-in').extract()
        sizes = [re.findall('[0-9]+', size) for size in sizes]
        try:
            sizes = ['waist:{} and bust:{}'.format(size[0], size[1]) for size in sizes]
        except:
            try:
                sizes = ['bust:{}'.format(size[0]) for size in sizes]
            except:
                sizes = []
        prod['Sizes'] = sizes

        prod['originalPrice'] = response.xpath('//span[@class="mrp"]/text()').extract_first()
        prod['currentPrice'] = response.xpath('//span[@class="sell"]/text()').extract_first()
        prod['discount'] = response.xpath('//span[@class="per"]/text()').extract_first()

        prod['Wash_Care'] = response.xpath('//div[@class="p80 pt0"]/span/text()').extract_first()

        brand_details = response.xpath('//div[@class="c9 ttL"]/span/text()').extract()
        brand_details = ' '.join(brand_details)
        prod['Brand_Details'] = brand_details

        details_key = response.xpath('//div[@class="dIb vT"]/text()').extract()
        details_val = response.xpath('//div[@class="dIb vT c3"]/text()').extract()
        prod_details = {key: val for key, val in zip(details_key, details_val)}
        prod['product_detail'] = json.dumps(prod_details)

        description = response.xpath('//li[@class="pb6"]/text()').extract()
        description = ' '.join(description)
        prod['Description'] = description

        image_list = response.xpath('//div[@class="m02 vT dIb pR zmimgH w310 h412 z2"]/img/@data-src').extract()
        image_list += response.xpath('//div[@class="m02 zmimgH vT dIb pR w310 h412 z2"]/img/@data-src').extract()
        prod['image_urls'] = SEPERATOR.join(image_list)

        yield prod





