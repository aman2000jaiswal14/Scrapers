import sys
import scrapy
import json
import math
import re
sys.path.insert(1, r'C:\Users\aman2\Desktop\Artyvis\Scraping\utils')
from write_data_utils import WriteData
from prev_index_utils import get_start_index,set_start_index
from scrapy.utils.project import get_project_settings
from twisted.internet import reactor
from scrapy.crawler import CrawlerRunner
from scrapy.utils.log import configure_logging

source = 'Ajio'
category = 'Men'
subcategory = 'Accessories'

### For Ajio ONLY - - - in parse_info_too

def get_processed_image(sample):
    attrib = []
    for s in sample:
        s = s.strip('\"\' ')
        try:
            model = s.split('-')[-1]

            shape = re.search('([0-9]+)Wx([0-9]+)H', s).group(0)
            shape = shape[:-1]
            shape = shape.split('Wx')

            shape = [int(shape[0]), int(shape[1])]

            attrib.append([shape, model, s])
        except:
            print(s)

    attrib.sort(reverse=True, key=lambda x: x[0][0] + x[0][1])

    uniq_image = set()
    image_list = []
    for num, s in enumerate(attrib):
        if (s[1] not in uniq_image):
            uniq_image.add(s[1])
            image_list.append(s[2])
    return image_list


from datetime import datetime
FILENAME = source+'_'+category+'_'+subcategory+'_'+(str(datetime.now())).replace(':','-').replace('.','-')
wd = WriteData(FILENAME,source,category,subcategory)


BASE = "https://www.ajio.com"
start_prod_id = get_start_index(source)

def cleanup(string):
    string = re.sub("[<p>]", "", string)
    return string
def cleanhtml(raw_html):
  cleanr = re.compile('<.*?>')
  cleantext = re.sub(cleanr, '', raw_html)
  return cleantext


def parse_info_help(response):
    global start_prod_id
    jd = json.loads(response.text)
    data = {}
    try:
        data['source'] = source
    except:
        data['source'] = source

    try:
        data['Native_product_id'] = response.meta['p_code']
    except:
        data['Native_product_id'] = None

    data['product_id'] = start_prod_id
    start_prod_id+=1


    try:
        data['Category'] = category
    except:
        data['Category'] = category

    try:
        data['Subcategory1'] = jd['brickSubCategory']
    except:
        data['Subcategory1'] = None

    try:
        data['Subcategory2'] = jd['brickName']
    except:
        data['Subcategory2'] = None

    try:
        data['Subcategory3'] = jd['brickName']
    except:
        data['Subcategory3'] = None


    try:
        data['Title'] = jd['name']
    except:
        data['Title'] = None

    try:
        data['Brand'] = jd['categories'][0]['code']
    except:
        data['Brand'] = None

    try:
        data['Item_url'] = response.meta['p_url']
    except:
        data['Item_url'] = None

    try:
        data['currentPrice'] = jd['baseOptions'][0]['selected']['priceData']['value']
    except:
        data['currentPrice'] = None

    try:
        data['orginalPrice'] = jd['baseOptions'][0]['selected']['wasPriceData']['value']
    except:
        data['orginalPrice'] = None

    try:
        data['discount'] = jd['baseOptions'][0]['selected']['priceData']['discountValue']
    except:
        data['discount'] = None

    try:
        data['currencyIso'] = jd['baseOptions'][0]['selected']['priceData']['currencyIso']
    except:
        data['currencyIso'] = None

    feature_list = {}
    try:
        for feat_data in jd['featureData']:
            feature_list.update({feat_data['name']: feat_data['featureValues'][0]['value']})
    except:
        pass

    try:
        data['product_detail'] = json.dumps(feature_list)
    except:
        data['product_detail'] = json.dumps({})

    try:
        data['PrimaryColor'] = jd['fnlColorVariantData']['color']
    except:
        data['PrimaryColor'] = None

    available_colors = []

    try:
        for opt in jd['baseOptions'][0]['options']:
            available_colors.append(opt['color'])
    except:
        pass

    try:
        data['available_colors'] = available_colors
    except:
        data['available_colors'] = None


    data["ManufacturedBy"] = ""
    data["CountryOfOrigin"] = ""

    try:
        for mandinfo in jd['mandatoryInfo']:
            if (mandinfo['key'] == "Manufactured By"):
                data["ManufacturedBy"] = mandinfo['title']

            if (mandinfo['key'] == "Country Of Origin"):
                data["CountryOfOrigin"] = mandinfo['title']
    except:
        pass

    list_of_images = []
    try:
        for imgs in jd['images']:
            list_of_images.append(imgs['url'])
    except:
        pass
    list_of_images = list(set(list_of_images))

    try:
        data['image_urls'] = json.dumps(get_processed_image(list_of_images))
    except:
        data['image_urls'] = json.dumps([])

    try:
        data['sizeTag'] = json.dumps([size['scDisplaySize'] for size in jd['variantOptions']])
    except:
        data['sizeTag'] = json.dumps([])


    try:
        data['Description'] = cleanhtml(jd['description'])
    except:
        try:
            data['Description'] = jd['description']
        except:
            data['Description'] = ""


    try:
        data['Ratings'] = None #jd['ratings']['averageRating']
    except:
        data['Ratings'] = None

    try:
        data['Review_counts'] = None #jd['ratings']['totalCount']
    except:
        data['Review_counts'] = None

    try:
        data['SeasonYear'] = jd['fnlProductData']['seasonYear']
    except:
        data['SeasonYear'] = None

    try:
        data['Season'] = None   #jd['catalogAttributes']['season']
    except:
        data['Season'] = None

    try:
        data['Occasion'] = jd['fnlProductData']['productGroups']
    except:
        data['Occasion'] = ""

    try:
        data['fashionType'] = jd['fnlProductData']['fashionType']
    except:
        data['fashionType'] = ""

    try:
        data['Design_Styling'] = jd['fnlProductData']['styleType']
    except:
        data['Design_Styling'] = ""

    try:
        data['productType'] = jd['fnlProductData']['productType']
    except:
        data['productType'] = ""

    try:
        data['productGroups'] = jd['fnlProductData']['productGroups']
    except:
        data['productGroups'] = ""

    try:
        data['modelImage'] = jd['baseOptions'][0]['selected']['modelImage']['url']
    except:
        data['modelImage'] = ""

    wd.writedata(data)
    # return data
    set_start_index(source,start_prod_id)
    return {'success':start_prod_id}


class Spider1(scrapy.Spider):
    name = 'Accessories'
    base_url ="https://www.ajio.com/api/category/8302?fields=SITE&currentPage={}&pageSize=45&format=json&query=%3Arelevance&sortBy=relevance&curated=true&curatedid=men-accessories-brands&gridColumns=3&facets=&advfilter=true"
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }
    def start_requests(self):
        TOTALPAGES = 500
        try:
            for i in range(1,TOTALPAGES):
                next_page = self.base_url.format(i)
                try:
                    yield scrapy.Request(url=next_page, headers=self.headers, callback=self.parse)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def parse(self, response):
        json_data = json.loads(response.text)

        for product in json_data['products']:
            try:
                prod_url = 'https://www.ajio.com/api/p/' + product['code']
                p_url = BASE + product['url']
                yield scrapy.Request(url=prod_url, headers=self.headers, callback=self.parse_info,
                                     meta={'p_url': p_url,'p_code':product['code']})
            except Exception as e:
                print(e)

    def parse_info(self, response):
        result = parse_info_help(response)
        yield result



class Spider2(scrapy.Spider):
    name = 'jewellery'
    base_url ="https://www.ajio.com/api/category/83?fields=SITE&currentPage={}&pageSize=45&format=json&query=%3Arelevance&sortBy=relevance&curated=true&curatedid=precious-jewellery-4119-63402&gridColumns=3&facets=&advfilter=true"
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }
    def start_requests(self):
        TOTALPAGES = 50
        try:
            for i in range(1,TOTALPAGES):
                next_page = self.base_url.format(i)
                try:
                    yield scrapy.Request(url=next_page, headers=self.headers, callback=self.parse)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def parse(self, response):
        json_data = json.loads(response.text)

        for product in json_data['products']:
            try:
                prod_url = 'https://www.ajio.com/api/p/' + product['code']
                p_url = BASE + product['url']
                yield scrapy.Request(url=prod_url, headers=self.headers, callback=self.parse_info,
                                     meta={'p_url': p_url,'p_code':product['code']})
            except Exception as e:
                print(e)

    def parse_info(self, response):
        result = parse_info_help(response)
        yield result



class Spider3(scrapy.Spider):
    name = 'Home_kitchen'
    base_url ="https://www.ajio.com/api/category/83?fields=SITE&currentPage={}&pageSize=45&format=json&query=%3Arelevance&sortBy=relevance&curated=true&curatedid=home-and-kitchen-4133-59091&gridColumns=3&facets=&advfilter=true"
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }
    def start_requests(self):
        TOTALPAGES = 800
        try:
            for i in range(1,TOTALPAGES):
                next_page = self.base_url.format(i)
                try:
                    yield scrapy.Request(url=next_page, headers=self.headers, callback=self.parse)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def parse(self, response):
        json_data = json.loads(response.text)

        for product in json_data['products']:
            try:
                prod_url = 'https://www.ajio.com/api/p/' + product['code']
                p_url = BASE + product['url']
                yield scrapy.Request(url=prod_url, headers=self.headers, callback=self.parse_info,
                                     meta={'p_url': p_url,'p_code':product['code']})
            except Exception as e:
                print(e)

    def parse_info(self, response):
        result = parse_info_help(response)
        yield result

class Spider4(scrapy.Spider):
    name = 'Grooming'
    base_url ="https://www.ajio.com/api/category/83?fields=SITE&currentPage={}&pageSize=45&format=json&query=%3Arelevance&sortBy=relevance&curated=true&curatedid=grooming-4384-57431&gridColumns=3&facets=&advfilter=true"
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }
    def start_requests(self):
        TOTALPAGES = 20
        try:
            for i in range(1,TOTALPAGES):
                next_page = self.base_url.format(i)
                try:
                    yield scrapy.Request(url=next_page, headers=self.headers, callback=self.parse)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def parse(self, response):
        json_data = json.loads(response.text)

        for product in json_data['products']:
            try:
                prod_url = 'https://www.ajio.com/api/p/' + product['code']
                p_url = BASE + product['url']
                yield scrapy.Request(url=prod_url, headers=self.headers, callback=self.parse_info,
                                     meta={'p_url': p_url,'p_code':product['code']})
            except Exception as e:
                print(e)

    def parse_info(self, response):
        result = parse_info_help(response)
        yield result



configure_logging()

runner = CrawlerRunner(get_project_settings())

runner.crawl(Spider1)
#
runner.crawl(Spider2)
runner.crawl(Spider3)
runner.crawl(Spider4)
# runner.crawl(Spider5)
# runner.crawl(Spider6)
# runner.crawl(Spider7)
d = runner.join()

d.addBoth(lambda _: reactor.stop())

try:
    reactor.run()
except:
    pass
