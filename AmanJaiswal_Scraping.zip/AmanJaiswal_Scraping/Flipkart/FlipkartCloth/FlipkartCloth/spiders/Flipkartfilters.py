import os

def brand_filters():
    res = []
    with open('FIlters_folder/Brand_F_skirts','r') as f:
        l = f.readlines()
    toadd  = '&p%5B%5D=facets.brand%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd+sii)
    return res

def size_filters():
    res = []
    with open('FIlters_folder/Size_F_shorts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.size%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def length_filters():
    res = []
    with open('FIlters_folder/Length_F_shorts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.length%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res


def ratings_filters():
    res = []
    with open('FIlters_folder\Ratings_F', 'r') as f:
        l = f.readlines()
    res = []
    for i in l:
        ii = i.split('\n')[0]
        res.append(ii)
    return res

def discount_filters():
    res = []
    with open('FIlters_folder\Discount_F', 'r') as f:
        l = f.readlines()
    res = []
    for i in l:
        ii = i.split('\n')[0]
        res.append(ii)
    return res



def fit_filters():
    res = []
    with open('FIlters_folder/Fit_F_shorts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.fit%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def waistrise_filters():
    res = []
    with open('FIlters_folder/Waistrise_F_Jeans', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.waist_rise%255B%255D%3DHigh%2BRise'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def fade_filters():
    res = []
    with open('FIlters_folder/Fade_F_Jeans', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.fade%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res


def color_filters():
    res = []
    with open('FIlters_folder/Color_F_skirts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.color%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def skirtlength_filters():
    res = []
    with open('FIlters_folder/Skirtlength_F_skirts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.skirt_length%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def distress_filters():
    res = []
    with open('FIlters_folder/Distress_F_Jeans', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.distress%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res


def theme_filters():
    res = []
    with open('FIlters_folder/Theme_F_Jeans', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.theme%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res


def pattern_filters():
    res = []
    with open('FIlters_folder/Pattern_F_skirts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.pattern%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def fabric_filters():
    res = []
    with open('FIlters_folder/Fabric_F_shorts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.fabric%255B%255D%3D'

    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res




def neck_filters():
    res = []
    with open('FIlters_folder/Neck_F', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.neck%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def sleeve_filters():
    res = []
    with open('FIlters_folder/Sleeve_F', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.sleeve_style%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res


def sleevelength_filters():
    res = []
    with open('FIlters_folder/Sleevelength_F', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.sleeve_length%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def occasion_filters():
    res = []
    with open('FIlters_folder/Occasion_F_skirts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.occasion%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res

def dresslength_filters():
    res = []
    with open('FIlters_folder/Dresslength_F', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.dress_length%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res


def type_filters():
    res = []
    with open('FIlters_folder/Type_F_shorts', 'r') as f:
        l = f.readlines()
    toadd = '&p%5B%5D=facets.type%255B%255D%3D'
    for i in l:
        ii = i.split('\n')[0]
        sii = ii.split(' ')
        sii = '%2B'.join(sii)
        res.append(toadd + sii)
    return res





def combine_filters_Dresses():
    res = []
    res+=brand_filters()
    res+=ratings_filters()
    res+=discount_filters()
    res+=color_filters()
    res+=size_filters()
    res+=fabric_filters()
    res+=theme_filters()
    res+=neck_filters()
    res+=sleeve_filters()
    res+=pattern_filters()
    res+=sleevelength_filters()
    res+=occasion_filters()
    res+=dresslength_filters()
    res+=type_filters()
    return res

def combine_filters_Jeans():
    res = []
    res += brand_filters()
    res += ratings_filters()
    res += size_filters()
    res += discount_filters()
    res += fit_filters()
    res += waistrise_filters()
    res += fade_filters()
    res += color_filters()
    res += distress_filters()
    res += theme_filters()
    res += pattern_filters()
    res += fabric_filters()

    return res

def combine_filters_shorts():
    res = []
    res+=brand_filters()
    res+=ratings_filters()
    res+=size_filters()
    res+=discount_filters()
    res+=length_filters()
    res+=occasion_filters()
    res+=type_filters()
    res+=color_filters()
    res+=fabric_filters()
    res+=pattern_filters()
    res+=fit_filters()
    return res

def combine_filters_skirts():
    res = []
    res += brand_filters()
    res += ratings_filters()
    res += discount_filters()
    res += color_filters()
    res += skirtlength_filters()
    res += pattern_filters()
    res += occasion_filters()
    return res