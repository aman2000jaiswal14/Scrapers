
import os
import csv
import re
import json
import hashlib
import scrapy
import Flipkartfilters
# from Flipkartfilters import combine_filters as CF
from scrapy.crawler import CrawlerProcess
TOTALPAGES = 26                         # change

TOTAL_REVIEWS_PAGES = 0                            # for reviews
EXTRACT_REVIEW = False                             # for reviews
## Filters
# ----------------------------------------------------------------------------------------

filters = Flipkartfilters.combine_filters_skirts()
# filters = filters[0:1]                             # Change
# print(filters)
# -------------------------------------------------------------------------------------------


## Product Counter
# -------------------------------------------------------------------------------------------
unique_products = set()
duplicate_products = set()
TOTAL_PRODUCTS = 0
SUCCESS_PRODUCTS = 0
DUPLICATES = 0
COUNTERS = 0
# -------------------------------------------------------------------------------------------

## Files and Headers
# --------------------------------------------------------------------------------------------
FILENAME = 'Flipkart_skirts.{}'
CSV_FILENAME= FILENAME.format('csv')
JSON_FILENAME = FILENAME.format('json')
ERROR_FILENAME = FILENAME.format('error.csv')

HEADER = ['category','subcategory1','subcategory2','subcategory3','title','description','brand','current_price','original_price',
'discount','prod_url','image_urls','product_details','seller_name','sizes','sizestag','Count_Ratings_and_Reviews',
'rating','reviews','available_colors']

def create_csv_header(header):
    try:
        with open(CSV_FILENAME,'w',newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(header)
    except Exception as e:
        print(e)
        pass
create_csv_header(HEADER)
def write_to_csv(data):
    try:
        with open(CSV_FILENAME,'a',newline='',encoding='utf-8') as csv_file:
            writer = csv.DictWriter(csv_file,fieldnames=data.keys())
            writer.writerow(data)
    except Exception as e:
        print(e)
        pass

def error_in_data_head():
    try:
        with open(ERROR_FILENAME,'w',newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(['error_code','url','error'])
    except Exception as e:
        print(e)
        pass
error_in_data_head()
def error_in_data(data):
    try:
        if(not os.path.exists(ERROR_FILENAME)):
            error_in_data_head()
        with open(ERROR_FILENAME,'a',newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(data)
    except Exception as e:
        print(e)
        pass
# --------------------------------------------------------------------------------------------

def prod_info(data):
    items = {} #FlipkartScrapItem()
    try:
        items['category'] = data['categories'][4]
    except:
        items['category'] = ""
    try:
        items['subcategory1'] = data['categories'][2]
    except:
        items['subcategory1'] = ""
    try:
        items['subcategory2'] = data['categories'][3]
    except:
        items['subcategory2'] = ""
    try:
        items['subcategory3'] = data['categories'][5]
    except:
        items['subcategory3'] = ""

    try:
        items['title'] = data['name']
    except:
        items['title'] = ""

    try:
        items['description'] = data['description']
    except:
        items['description'] = ""

    try:
        items['brand'] = data['brand'].split('\xa0')[0]
    except:
        items['brand'] = ""
    try:
        items['current_price'] = data['current_price'][1:]
    except:
        items['current_price'] = ""
    try:
        items['original_price'] = data['original_price'][1]
    except:
        items['original_price'] = ""

    try:
        items['discount'] = data['discount']
    except:
        items['discount'] = ""

    try:
        items['prod_url']  = data['prod_url']
    except:
        items['prod_url'] = ""

    img_urls = []
    try:
        for img in data['images']:
            start_id = img.index('(') + 1
            end_id = img.index(')')
            img_urls.append(img[start_id:end_id])
    except:
        pass
    try:
        items['image_urls'] = img_urls
    except:
        items['image_urls'] = []

    try:
        prod_details = {}
        for key,val in  zip(data['product_details_keys'],data['product_details_values']):
            prod_details[key] = val
        items['product_details'] = json.dumps(prod_details)
    except:
        items['product_details'] = {}

    try:
        items['seller_name'] = data['seller_name']
    except:
        items['seller_name'] = ""

    try:
        sizes = []
        colors = []
        for i in data['colors_and_sizes']:
            if(('Waist' in i )or ('Bust' in i) or ('inch' in i)):
                sizes.append(i)
            elif('Hurry' in i):
                continue
            else:
                try:
                    if(i in data['all_size']):
                        sizes.append(i)
                    else:
                        colors.append(i)
                except:
                    colors.append(i)
        items['sizes'] = sizes
    except:
        items['sizes'] = []

    try:
        items['sizestag'] = data['sizestag']
    except:
        items['sizestag'] = []

    try:
        items['Count_Ratings_and_Reviews'] = data['Count_Ratings_and_Reviews']
    except:
        items['Count_Ratings_and_Reviews'] = ''

    try:
        items['rating'] = data['rating']
    except:
        items['rating'] = ""

    try:
        items['reviews'] = data['reviews']
    except:
        items['reviews'] = []

    try:
        items['available_colors'] = colors
    except:
        items['available_colors'] = []

    write_to_csv(items)

    # return items

BASE = 'https://www.flipkart.com'
class ScrapperSpider(scrapy.Spider):
    name = 'copy_scrapper_flip'
    base_url = 'https://www.flipkart.com/clothing-and-accessories/bottomwear/skirts/women-skirts/pr?sid=clo%2Cvua%2Ciku%2Cw5t&otracker=categorytree&otracker=nmenu_sub_Women_0_Skirts'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        try:
            for filter_i in filters:
                try:
                    for pageno in range(1,TOTALPAGES):
                        try:
                            print(filter_i,pageno)
                            next_page = self.base_url+filter_i+'&page={}'.format(pageno)
                            yield scrapy.Request(url=next_page, headers=self.headers, callback=self.parse)
                        except Exception as e:
                            print(e)
                            print(pageno)
                            error_in_data([1,'pageno {}'.format(pageno),e])
                except Exception as e:
                    print(e)
                    print(filter_i)
                    error_in_data([2,'filter_i {}'.format(filter_i),e])

        except Exception as e:
            print(e)
            error_in_data([3,'start',e])

    def parse(self, response):
        try:
            urls = response.xpath('//a[@class="_2UzuFa"]//@href').extract()
            for u in urls:
                try:
                    global COUNTERS
                    COUNTERS += 1
                    print(COUNTERS)
                    prod_url = BASE + u
                    prod_url = prod_url.split('&lid')[0]
                    yield scrapy.Request(url=prod_url, headers=self.headers, callback=self.goto_product)
                except Exception as e:
                    error_in_data([5, u, e])
        except Exception as e:
            error_in_data([4,response.url,e])


    def goto_product(self,response):
        try:
            diff_color_product = response.xpath('//a[@class="kmlXmn _31hAvz"]/@href').extract()
            diff_sizes_product1 = response.xpath('//a[@class="_1fGeJ5 _2UVyXR _31hAvz"]/@href').extract()
            diff_sizes_product2 = response.xpath('//a[@class="_1fGeJ5 _2UVyXR _1ynmf9"]/@href').extract()
            to_diff = set(diff_color_product+diff_sizes_product1+diff_sizes_product2)
            for u in to_diff:
                try:
                    global COUNTERS
                    COUNTERS += 1
                    print(COUNTERS)
                    prod_url = BASE + u
                    prod_url = prod_url.split('&lid')[0]
                    yield scrapy.Request(url=prod_url, headers=self.headers, callback=self.goto_product1)
                except:
                    pass

        except:
            pass

        try:
            global SUCCESS_PRODUCTS
            data = {
            'prod_url':response.url,
            'categories' : response.xpath('//a[@class="_2whKao"]//text()').extract(),
            'brand' : response.xpath('//span[@class="G6XhRU"]//text()').extract_first(),
            'name' : response.xpath('//span[@class="B_NuCI"]//text()').extract_first(),
            'current_price' : response.xpath('//div[@class="_30jeq3 _16Jk6d"]//text()').extract_first(),
            'original_price' : response.xpath('//div[@class="_3I9_wc _2p6lqe"]//text()').extract(),
            'discount' : response.xpath('//div[@class="_3Ay6Sb _31Dcoz pZkvcx"]//text()').extract_first(),
            'colors_and_sizes' : response.xpath('//div[@class="_3Oikkn _3_ezix _2KarXJ _31hAvz"]//text()').extract(),
            'sizestag' : response.xpath('//a[@class="_1fGeJ5 _2UVyXR _31hAvz"]//text()').extract(),
            'images'  : response.xpath('//div[@class="q6DClP _2_B7hD"]/@style').extract(),
            'product_details_keys' : response.xpath('//div[@class="col col-3-12 _2H87wv"]//text()').extract(),
            'product_details_values' : response.xpath('//div[@class="col col-9-12 _2vZqPX"]//text()').extract(),
            'rating' : response.xpath('//div[@class="_3LWZlK _138NNC"]//text()').extract_first(),
            'description' : response.xpath('//div[@class="_1AN87F"]//text()').extract_first(),
            'Count_Ratings_and_Reviews':response.xpath('//span[@class="_2_R_DZ _2IRzS8"]//text()').extract_first(),
            'reviews':[],
            'review_page_len':0
            }
            try:
                data['all_size'] = response.xpath('//a[@class="_1fGeJ5 _2UVyXR _1ynmf9"]/text()').extract() +data['sizestag']
            except:
                data['all_size'] = data['sizestag']
            try:
                data['seller_name'] = response.xpath('//div[@class="_1RLviY"]')[0].xpath('.//span/text()').extract_first()
            except:
                data['seller_name'] = ""
            try:
                if(data['rating']==""):
                    data['rating'] = response.xpath('//div[@class="_3LWZlK _32lA32 _138NNC"]//text()').extract_first()
            except:
                pass
            if(not EXTRACT_REVIEW):
                SUCCESS_PRODUCTS+=1
                print('SUCCESS_PRODUCTS : {},DUPLICATES : {},TOTAL_PRODUCTS : {}'.format(SUCCESS_PRODUCTS,DUPLICATES,TOTAL_PRODUCTS))
                yield prod_info(data)

            else:
                try:
                    SUCCESS_PRODUCTS += 1
                    print('SUCCESS_PRODUCTS : {},DUPLICATES : {},TOTAL_PRODUCTS : {}'.format(SUCCESS_PRODUCTS, DUPLICATES,
                                                                                           TOTAL_PRODUCTS))
                    page = response.xpath('//div[@class="col JOpGWq _33R3aa"]/a/@href').extract_first()
                    if(page is None):
                        revs = response.xpath('//div[@class="_6K-7Co"]/text()').extract()
                        for rev in revs:
                            data['reviews'].append(rev)
                        yield prod_info(data)
                    else:
                        review_page = BASE + page
                        req = scrapy.Request(url=review_page, headers=self.headers, callback=self.get_all_reviews,meta = {'data':data})
                        yield req
                except:
                    yield prod_info(data)
        except Exception as e:
            print(e)
            error_in_data([6,response.url,e])


    def goto_product1(self,response):
        try:
            global SUCCESS_PRODUCTS
            data = {
            'prod_url':response.url,
            'categories' : response.xpath('//a[@class="_2whKao"]//text()').extract(),
            'brand' : response.xpath('//span[@class="G6XhRU"]//text()').extract_first(),
            'name' : response.xpath('//span[@class="B_NuCI"]//text()').extract_first(),
            'current_price' : response.xpath('//div[@class="_30jeq3 _16Jk6d"]//text()').extract_first(),
            'original_price' : response.xpath('//div[@class="_3I9_wc _2p6lqe"]//text()').extract(),
            'discount' : response.xpath('//div[@class="_3Ay6Sb _31Dcoz pZkvcx"]//text()').extract_first(),
            'colors_and_sizes' : response.xpath('//div[@class="_3Oikkn _3_ezix _2KarXJ _31hAvz"]//text()').extract(),
            'sizestag' : response.xpath('//a[@class="_1fGeJ5 _2UVyXR _31hAvz"]//text()').extract(),
            'images'  : response.xpath('//div[@class="q6DClP _2_B7hD"]/@style').extract(),
            'product_details_keys' : response.xpath('//div[@class="col col-3-12 _2H87wv"]//text()').extract(),
            'product_details_values' : response.xpath('//div[@class="col col-9-12 _2vZqPX"]//text()').extract(),
            'rating' : response.xpath('//div[@class="_3LWZlK _138NNC"]//text()').extract_first(),
            'description' : response.xpath('//div[@class="_1AN87F"]//text()').extract_first(),
            'Count_Ratings_and_Reviews':response.xpath('//span[@class="_2_R_DZ _2IRzS8"]//text()').extract_first(),
            'reviews':[],
            'review_page_len':0
            }
            try:
                data['all_size'] = response.xpath('//a[@class="_1fGeJ5 _2UVyXR _1ynmf9"]/text()').extract() +data['sizestag']
            except:
                data['all_size'] = data['sizestag']
            try:
                data['seller_name'] = response.xpath('//div[@class="_1RLviY"]')[0].xpath('.//span/text()').extract_first()
            except:
                data['seller_name'] = ""
            try:
                if(data['rating']==""):
                    data['rating'] = response.xpath('//div[@class="_3LWZlK _32lA32 _138NNC"]//text()').extract_first()
            except:
                pass
            if(not EXTRACT_REVIEW):
                SUCCESS_PRODUCTS+=1
                print('SUCCESS_PRODUCTS : {},DUPLICATES : {},TOTAL_PRODUCTS : {}'.format(SUCCESS_PRODUCTS,DUPLICATES,TOTAL_PRODUCTS))
                yield prod_info(data)

            else:
                try:
                    SUCCESS_PRODUCTS += 1
                    print('SUCCESS_PRODUCTS : {},DUPLICATES : {},TOTAL_PRODUCTS : {}'.format(SUCCESS_PRODUCTS, DUPLICATES,
                                                                                           TOTAL_PRODUCTS))
                    page = response.xpath('//div[@class="col JOpGWq _33R3aa"]/a/@href').extract_first()
                    if(page is None):
                        revs = response.xpath('//div[@class="_6K-7Co"]/text()').extract()
                        for rev in revs:
                            data['reviews'].append(rev)
                        yield prod_info(data)
                    else:
                        review_page = BASE + page
                        req = scrapy.Request(url=review_page, headers=self.headers, callback=self.get_all_reviews,meta = {'data':data})
                        yield req
                except:
                    yield prod_info(data)
        except Exception as e:
            print(e)
            error_in_data([6,response.url,e])



    def get_all_reviews(self,response):
        try:
            data = response.meta['data']
            if(len(data['reviews'])==0):
                first = True
            else:
                first = False
            reviews = response.xpath('//div[@class="_6K-7Co"]/text()').extract()
            data['review_page_len']+=1
            for rev in reviews:
                data['reviews'].append(rev)

            next_page = response.xpath('//a[@class="_1LKTO3"]/@href').extract()
            if(len(next_page)==0):
                yield prod_info(data)
            elif(first):
                next_page = BASE + next_page[0]
                yield scrapy.Request(url=next_page, headers=self.headers, callback=self.get_all_reviews,
                                     meta={'data': data})
            elif(len(next_page)==2 and data['review_page_len']<TOTAL_REVIEWS_PAGES):
                next_page = BASE+next_page[1]
                yield scrapy.Request(url=next_page, headers=self.headers, callback=self.get_all_reviews,meta = {'data':data})
            else:
                yield prod_info(data)
        except Exception as e:
            error_in_data([7,response.url,e])
            print(e)
# '''
process = CrawlerProcess()
process.crawl(ScrapperSpider)
process.start()
print('COMPLETED ....    ')

# '''