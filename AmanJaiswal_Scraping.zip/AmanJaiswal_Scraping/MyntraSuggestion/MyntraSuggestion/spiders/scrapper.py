import scrapy
import json
import math
import re
from scrapy.loader import ItemLoader
# from ..items import MyntraProduct
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from twisted.internet import reactor
from scrapy.crawler import CrawlerRunner
from scrapy.utils.log import configure_logging
base = "https://www.myntra.com/web/v2/search/{}?p={}&plaEnabled=false&rows=50&o={}"

ITEM_SUGGESTION = []
COUNT_SUGGESTION = 20
MULTIPLIER = 20

import pandas as pd
filename = 'Label_ref_v1.xlsx'
df = pd.read_excel(filename,sheet_name='Women_Tops')
def isNaN(string):
    return string != string

for col in df.columns:
    for row in range(df.shape[0]):
        if(not isNaN(df[col][row])):
            ITEM_SUGGESTION.append(str(df[col][row])+' Tops')
            ITEM_SUGGESTION.append(str(df[col][row])+' Dresses')


def cleanup(string):
    string = re.sub("[<p>]", "", string)
    return string

def parse_info_help(response):
    product = MyntraProduct()
    product['SuggestionLabel'] = response.meta['suggestion_label']
    product['Item_url'] = response.meta['item_url']
    item = json.loads(response.text)
    images = item[0]['style']['media']['albums'][0]['images']
    colours = item[0]['style']['colours']
    if colours != None:
        product['Available_colours'] = [colour['label'] for colour in colours]
    else:
        product['Available_colours'] = colours

    product['Category'] = item[0]['style']['analytics']['gender']
    product['SubCategory1'] = item[0]['style']['analytics']['masterCategory']
    product['SubCategory2'] = item[0]['style']['analytics']['subCategory']
    product['SubCategory3'] = item[0]['style']['analytics']['articleType']
    product['Tittle'] = item[0]['style']['name']
    product['Brand'] = item[0]['style']['analytics']['brand']
    product['Colour'] = item[0]['style']['baseColour']
    for descriptor in item[0]['style']['descriptors']:
        if descriptor['title'] == 'description':
           product['Description'] = cleanup(descriptor['description'].split('<br>')[0])
    product['CountryOfOrigin'] = item[0]['style']['countryOfOrigin']
    product['Original_price'] = item[0]['style']['price']['mrp']
    product['Selling_price'] = item[0]['style']['price']['discounted']
    try:
        product['Images'] = [image['imageURL'] for image in images]
    except KeyError:
        product['Images'] = 'Not Found'
    try:
        product['Pattern'] = item[0]['style']['articleAttributes']['Pattern']
    except KeyError:
        product['Pattern'] = None
    try:
        product['Sleeve_Length'] = item[0]['style']['articleAttributes']['Sleeve Length']
    except KeyError:
        product['Sleeve_Length'] = None
    try:
        product['Closure'] = item[0]['style']['articleAttributes']['Closure']
    except KeyError:
        product['Closure'] = None
    try:
        product['Occasion'] = item[0]['style']['articleAttributes']['Occasion']
    except KeyError:
        product['Occasion'] = None
    try:
        product['Print'] = item[0]['style']['articleAttributes']['Print or Pattern Type']
    except KeyError:
        product['Print'] = None
    try:
        product['Wash_Care'] = item[0]['style']['articleAttributes']['Wash Care']
    except KeyError:
        product['Wash_Care'] = None
    try:
        product['Number_of_Pockets'] = item[0]['style']['articleAttributes']['Number of Pockets']
    except KeyError:
        product['Number_of_Pockets'] = None
    try:
        product['Type'] = item[0]['style']['articleAttributes']['Type']
    except KeyError:
        product['Type'] = None
    try:
        product['Length'] = item[0]['style']['articleAttributes']['Length']
    except KeyError:
        product['Length'] = None
    try:
        product['Fabric'] = item[0]['style']['articleAttributes']['Fabric']
    except KeyError:
        product['Fabric'] = None
    try:
       product['Collar'] = item[0]['style']['articleAttributes']['Collar']
    except KeyError:
        product['Collar'] = None
    try:
        product['Neck'] = item[0]['style']['articleAttributes']['Neck']
    except KeyError:
        product['Neck'] = None
    try:
        product['Hood'] = item[0]['style']['articleAttributes']['Hood']
    except KeyError:
        product['Hood'] = None
    try:
        product['Weave_Pattern'] = item[0]['style']['articleAttributes']['Weave Pattern']
    except KeyError:
        product['Weave_Pattern'] = None
    try:
        product['Sleeve_Styling'] = item[0]['style']['articleAttributes']['Sleeve Styling']
    except KeyError:
        product['Sleeve_Styling'] = None
    try:
        product['Shape'] = item[0]['style']['articleAttributes']['Shape']
    except KeyError:
        product['Shape'] = None
    try:
        product['Stitch'] = item[0]['style']['articleAttributes']['Stitch']
    except KeyError:
        product['Stitch'] = None
    try:
        product['Design_Styling'] = item[0]['style']['articleAttributes']['Design Styling']
    except KeyError:
        product['Design_Styling'] = None
    try:
        product['Colour_Family'] = item[0]['style']['articleAttributes']['Colour Family']
    except KeyError:
        product['Colour_Family'] = None
    try:
        product['Slit_Detail'] = item[0]['style']['articleAttributes']['Slit Detail']
    except KeyError:
        product['Slit_Detail'] = None
    try:
        product['Ornamentation'] = item[0]['style']['articleAttributes']['Ornamentation']
    except KeyError:
        product['Ornamentation'] = None
    try:
        product['Waistband'] = item[0]['style']['articleAttributes']['Waistband']
    except KeyError:
        product['Waistband'] = None
    try:
        product['Stretch'] = item[0]['style']['articleAttributes']['Stretch']
    except KeyError:
        product['Stretch'] = None
    try:
        product['Distress'] = item[0]['style']['articleAttributes']['Distress']
    except KeyError:
        product['Distress'] = None
    try:
        product['Fit'] = item[0]['style']['articleAttributes']['Fit']
    except KeyError:
        product['Fit'] = None
    try:
        product['Fade'] = item[0]['style']['articleAttributes']['Fade']
    except KeyError:
        product['Fade'] = None
    try:
        product['Ratings'] = round(item[0]['style']['ratings']['averageRating'], 1)
    except TypeError:
        product['Ratings'] = None
    try:
        product['Dupatta_Fabric'] = item[0]['style']['articleAttributes']['Dupatta Fabric']
    except KeyError:
        product['Dupatta_Fabric'] = None
    try:
        product['Bottom_Pattern'] = item[0]['style']['articleAttributes']['Bottom Pattern']
    except KeyError:
        product['Bottom_Pattern'] = None
    try:
        product['Top_Pattern'] = item[0]['style']['articleAttributes']['Top Pattern']
    except KeyError:
        product['Top_Pattern'] = None
    try:
        product['Top_Length'] = item[0]['style']['articleAttributes']['Top Length']
    except KeyError:
        product['Top_Length'] = None
    try:
        product['Bottom_Type'] = item[0]['style']['articleAttributes']['Bottom Type']
    except KeyError:
        product['Bottom_Type'] = None
    try:
        product['Dupatta'] = item[0]['style']['articleAttributes']['Dupatta']
    except KeyError:
        product['Dupatta'] = None
    try:
        product['Dupatta_Pattern'] = item[0]['style']['articleAttributes']['Dupatta Pattern']
    except KeyError:
        product['Dupatta_Pattern'] = None
    try:
        product['Bottom_Closure'] = item[0]['style']['articleAttributes']['Bottom Closure']
    except KeyError:
        product['Bottom_Closure'] = None
    try:
        product['Top_Type'] = item[0]['style']['articleAttributes']['Top Type']
    except KeyError:
        product['Top_Type'] = None
    try:
        product['Dupatta_Border'] = item[0]['style']['articleAttributes']['Dupatta Border']
    except KeyError:
        product['Dupatta_Border'] = None
    try:
        product['Top_Fabric'] = item[0]['style']['articleAttributes']['Top Fabric']
    except KeyError:
        product['Top_Fabric'] = None
    try:
        product['Bottom_Fabric'] = item[0]['style']['articleAttributes']['Bottom Fabric']
    except KeyError:
        product['Bottom_Fabric'] = None
    try:
        product['Top_Shape'] = item[0]['style']['articleAttributes']['Top Shape']
    except KeyError:
        product['Top_Shape'] = None
    try:
        product['Pattern_Coverage'] = item[0]['style']['articleAttributes']['Pattern Coverage']
    except KeyError:
        product['Pattern_Coverage'] = None
    try:
        product['Transparency'] = item[0]['style']['articleAttributes']['Transparency']
    except KeyError:
        product['Transparency'] = None
    try:
        product['Main_Trend'] = item[0]['style']['articleAttributes']['Main Trend']
    except KeyError:
        product['Main_Trend'] = None
    try:
        product['Surface_Styling'] = item[0]['style']['articleAttributes']['Surface Styling']
    except KeyError:
        product['Surface_Styling'] = None
    try:
        product['Technology'] = item[0]['style']['articleAttributes']['Technology']
    except KeyError:
        product['Technology'] = None
    try:
        product['Straps'] = item[0]['style']['articleAttributes']['Straps']
    except KeyError:
        product['Straps'] = None
    try:
        product['Coverage'] = item[0]['style']['articleAttributes']['Coverage']
    except KeyError:
        product['Coverage'] = None
    try:
        product['Sport'] = item[0]['style']['articleAttributes']['Sport']
    except KeyError:
        product['Sport'] = None
    try:
        product['Padding'] = item[0]['style']['articleAttributes']['Padding']
    except KeyError:
        product['Padding'] = None
    try:
        product['Seam'] = item[0]['style']['articleAttributes']['Seam']
    except KeyError:
        product['Seam'] = None
    try:
        product['Features'] = item[0]['style']['articleAttributes']['Features']
    except KeyError:
        product['Features'] = None
    try:
        product['Lining'] = item[0]['style']['articleAttributes']['Lining']
    except KeyError:
        product['Lining'] = None

    return product


class MyntraProduct(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    SuggestionLabel= scrapy.Field()
    Category = scrapy.Field()

    SubCategory2 = scrapy.Field()
    SubCategory3 = scrapy.Field()
    Tittle = scrapy.Field()
    Brand = scrapy.Field()
    Description = scrapy.Field()
    Original_price = scrapy.Field()
    Selling_price = scrapy.Field()
    Images = scrapy.Field()

    SubCategory1 = scrapy.Field()
    Pattern = scrapy.Field()
    CountryOfOrigin = scrapy.Field()
    Colour = scrapy.Field()
    Sleeve_Length = scrapy.Field()
    Type = scrapy.Field()
    Length = scrapy.Field()
    Wash_Care = scrapy.Field()
    Fabric = scrapy.Field()
    Collar = scrapy.Field()
    Number_of_Pockets = scrapy.Field()
    Occasion = scrapy.Field()
    Closure = scrapy.Field()
    Hemline = scrapy.Field()
    Print = scrapy.Field()
    Neck = scrapy.Field()
    Hood = scrapy.Field()
    Available_colours = scrapy.Field()
    Colour = scrapy.Field()
    Weave_Pattern = scrapy.Field()
    Sleeve_Styling = scrapy.Field()
    Shape = scrapy.Field()
    Stitch = scrapy.Field()
    Design_Styling = scrapy.Field()
    Colour_Family = scrapy.Field()
    Slit_Detail = scrapy.Field()
    Waistband = scrapy.Field()
    Stretch = scrapy.Field()
    Distress = scrapy.Field()
    Fit = scrapy.Field()
    Fade = scrapy.Field()
    Ornamentation = scrapy.Field()
    Ratings = scrapy.Field()
    Dupatta_Fabric = scrapy.Field()
    Bottom_Pattern = scrapy.Field()
    Top_Pattern = scrapy.Field()
    Top_Length = scrapy.Field()
    Bottom_Type = scrapy.Field()
    Dupatta_Pattern = scrapy.Field()
    Bottom_Closure = scrapy.Field()
    Top_Type = scrapy.Field()
    Dupatta_Border = scrapy.Field()
    Top_Fabric = scrapy.Field()
    Bottom_Fabric = scrapy.Field()
    Top_Shape = scrapy.Field()
    Pattern_Coverage = scrapy.Field()
    Dupatta = scrapy.Field()
    Transparency = scrapy.Field()
    Surface_Styling = scrapy.Field()
    Main_Trend = scrapy.Field()
    Technology = scrapy.Field()
    Straps = scrapy.Field()
    Coverage = scrapy.Field()
    Sport = scrapy.Field()
    Padding = scrapy.Field()
    Seam = scrapy.Field()
    Features = scrapy.Field()
    Lining = scrapy.Field()
    Item_url = scrapy.Field()

class Spider1(scrapy.Spider):
    name = 'myntra_product'

    start_urls = ["https://www.myntra.com/web/v2/search/fusion-wear?p=1&plaEnabled=false&rows=50&o=0"]

    def parse(self, response):
        Base_url = "https://www.myntra.com/web/v2/search/{}?p={}&plaEnabled=false&rows={}&o=0"
        page_count = math.ceil(COUNT_SUGGESTION/50)+1
        for item_s in ITEM_SUGGESTION:
            for pc in range(1,page_count):
                url = Base_url.format(item_s,pc,MULTIPLIER)
                yield scrapy.Request(url=url, callback=self.parse2,meta={'suggestion_label':item_s})

    def parse2(self, response):

        data = json.loads(response.text)

        total_item = data['totalCount']
        total_pages = math.ceil(int(total_item) / MULTIPLIER)

        o = 0

        for i in range(1, total_pages + 1):
            next_page = base.format('fusion-wear', i, o)
            o = o + 50
            yield scrapy.Request(url=next_page, callback=self.parse)

        for product in data['products']:
            Id = product['productId']
            url = product['landingPageUrl']
            item_url = f'https://www.myntra.com/{url}'
            absolute_url = f"https://www.myntra.com/amp/api/style/{Id}?__amp_source_origin=https%3A%2F%2Fwww.myntra.com"

            yield scrapy.Request(url=absolute_url, callback=self.parse_info, meta={'item_url': item_url,'suggestion_label':response.meta['suggestion_label']})

    def parse_info(self, response):
        result = parse_info_help(response)
        yield result

configure_logging()
runner = CrawlerRunner(get_project_settings())
runner.crawl(Spider1)
d = runner.join()
d.addBoth(lambda _: reactor.stop())
reactor.run()