import sys
import os
import pandas as pd
Root_path = r'C:\Users\aman2\Desktop\Artyvis\Scraping'

index_csv_path = os.path.join(Root_path,'utils','prev_index.csv')
allot_csv_path = os.path.join(Root_path,'utils','next_allot_index.csv')

def next_allot_index():
    df = pd.read_csv(allot_csv_path)
    increase = 10000000
    df['prev_allot'] = df['next_allot']
    df['next_allot'] = df['next_allot']+increase
    df.to_csv(allot_csv_path,index=False)
    return df['prev_allot'][0]

def get_start_index(source):
    df = pd.read_csv(index_csv_path)
    if(source not in df.source.values):
        startid = next_allot_index()
        rowcount = df.shape[0]
        newrow = pd.DataFrame({'id':[rowcount],'source':[source],'startid':[startid]})
        df = pd.concat([df,newrow],axis=0)
        df.to_csv(index_csv_path,index=False)

        return startid
    else:
        req_id = df[ df['source'] == source ]['id']

        return df['startid'][req_id].iloc[0]

def set_start_index(source,newstart):
    df = pd.read_csv(index_csv_path)
    req_id = df[df['source'] == source]['id'].iloc[0]
    df['startid'][req_id] = newstart
    df.to_csv(index_csv_path,index = False)

