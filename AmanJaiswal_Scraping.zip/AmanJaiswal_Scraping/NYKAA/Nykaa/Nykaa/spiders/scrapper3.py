
class ScrapperSpider15(scrapy.Spider):
    name = 'scrapper15'
    supercategory = 'Men'
    category = 'Accessories'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6875&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6882&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6883&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6881&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6867&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6886&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6885&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6884&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6880&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6887&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE']

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''] ]


        self.subcat = ["Watches","Belts","Ties Cufflinks and Pocket Squares","Wallets","Bags and Backpacks",
                        "Socks","Caps","Mufflers and Gloves","Sunglasses","Stationary"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct
