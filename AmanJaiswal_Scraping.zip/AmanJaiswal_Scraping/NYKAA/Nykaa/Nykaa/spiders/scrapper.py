import scrapy
import json
import csv
from scrapy.crawler import CrawlerProcess
PagesCount = 1
BASE = 'https://www.nykaafashion.com'
# FILTER = ['ships_in','bestseller','new_arrivals','popularity','high-to-low','low-to-high']
FILTER2 = ['&price_filter=175-800','&price_filter=800-1500','&price_filter=1500-83999']
# ['&shirts_tops_and_crop_tops_type_filter=1772','&shirts_tops_and_crop_tops_type_filter=1776',
#           '&shirts_tops_and_crop_tops_type_filter=2420','&shirts_tops_and_crop_tops_type_filter=1768']
FILENAME = 'Nykaa_women_tops3.{}'
CSV_FILENAME= FILENAME.format('csv')
# JSON_FILENAME = FILENAME.format('json')
# ERROR_FILENAME = FILENAME.format('error.csv')
COUNTER = 0

HEADER = ["category","subcategory1","subcategory2","subcategory3","brand","title",
            "description","product_detail","ManufacturedBy","AddressOfManufacturer","CountryOfOrigin","Wash_Care",
          "soldBy","currentPrice","orginalPrice","discount","image_urls","url","sizetag",
          "Return_and_Exchange_Policy","PackContains","product_id","category_ids"]





def create_csv_header(header):
    try:
        with open(CSV_FILENAME,'w',newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(header)
    except Exception as e:
        print(e)
        pass

create_csv_header(HEADER)

def write_to_csv(data):
    try:
        with open(CSV_FILENAME,'a',newline='',encoding='utf-8') as csv_file:
            writer = csv.DictWriter(csv_file,fieldnames=data.keys())
            writer.writerow(data)
    except Exception as e:
        print(e)
        pass



def parse_product(prod):
    data = {}

    try:
        data['category'] = prod['category']
    except:
        data['category'] = ""

    try:
        data['subcategory1'] = prod["subcategory1"]
    except:
        data['subcategory1'] = ""

    try:
        data['subcategory2'] = prod["subcategory2"]
    except:
        data['subcategory2'] = ""

    try:
        data['subcategory3'] = prod["subcategory3"]
    except:
        data['subcategory3'] = ""

    try:
        data['brand'] = prod["brand"]
    except:
        data['brand'] = ""

    try:
        data['title'] = prod['title']
    except:
        data['title'] = ""
    try:
        data['description'] = prod['Description']
    except:
        data['description'] = ""

    try:
        data['product_detail'] = json.dumps(prod['product_detail'])
    except:
        data['product_detail'] = []

    try:
        data['ManufacturedBy'] = prod["Name of Manufacturer/ Packer/ Importer"]
    except:
        data['ManufacturedBy'] = ""

    try:
        data['AddressOfManufacturer'] = prod["Address of Manufacturer/ Packer/ Importer"]
    except:
        data['AddressOfManufacturer'] = ""

    try:
        data['CountryOfOrigin'] = prod["Country of Origin"]
    except:
        data['CountryOfOrigin'] = ""

    try:
        data['Wash_Care'] = prod["Care Instructions"]
    except:
        data['Wash_Care'] = ""

    try:
        data['importedBy'] = prod["Sold By"]
    except:
        data['importedBy'] = ""

    try:
        data['currentPrice'] = prod["currentPrice"]
    except:
        data['currentPrice'] = ""

    try:
        data['orginalPrice'] = prod["originalPrice"]
    except:
        data['orginalPrice'] = ""


    try:
        data['discount'] = prod["discount"]
    except:
        data['discount'] = ""


    try:
        data['image_urls'] = prod["image_urls"]
    except:
        data['image_urls'] = None


    try:
        data['url'] = prod['url']
    except:
        data['url'] = ""

    try:
        data['sizetag'] = prod["sizetag"]
    except:
        data['sizetag'] = ""

    try:
        data['Return_and_Exchange_Policy'] = prod["Return and Exchange Policy"]
    except:
        data['Return_and_Exchange_Policy'] = ""


    try:
        data['PackContains'] = prod["Pack Contains"]
    except:
        data['PackContains'] = ""




    write_to_csv(data)




class ScrapperSpider(scrapy.Spider):
    name = 'scrapper'
    # base_url  = 'https://www.nykaafashion.com/westernwear/shirts-tops-and-crop-tops/c/4497?p={}'
    # base_url = 'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4497&PageSize=12&sort=popularity&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3'
    # base_url = 'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4497&PageSize=12&currentPage=1100'
    base_url = 'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4497&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        for filter in FILTER2:
            try:
                for i in range(1,PagesCount+1):
                    try:
                        print(filter,i)
                        url = self.base_url.format(filter,i)
                        yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)
                    except:
                        pass
            except:
                pass

    def parse(self, response):
        response = json.loads(response.text)
        products = response['response']['products']

        for prod in products:
            prod_url = BASE+prod['actionUrl']
            yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod)

    def goto_prod(self,response):

        oneproduct = {
                "category":"women",
                "subcategory1":"Wester Wear",
                "subcategory2": "Tops",
                "subcategory3":response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first(),
                "brand" : response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first(),
                "title"  : response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first(),
                "currentPrice" : response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first(),
                "discount" : response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first(),
                "originalPrice" : response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first(),
                "sizetag" : response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract(),
                "url":response.url
                }

        prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
        prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
        product_details = {i:j for i,j in zip(prod_detail_key,prod_detail_val)}
        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')

        for res in other_details1:
            try:
                head = res.xpath('.//div/text()').extract()
            except:
                head = ["",""]

            if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                if(len(head)>2):
                    val1 = '  '.join(head[1:])
                elif(len(head)==1):
                    val1 = res.xpath('.//div/p/text()').extract_first()
                else:
                    val1 = head[1]
                oneproduct[head[0]] = val1

        for res in other_details2:
            try:
                head = res.xpath('.//div/text()').extract()
            except:
                head = ["", ""]

            if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                if(len(head)>2):
                    val1 = '  '.join(head[1:])
                elif (len(head) == 1):
                    val1 = res.xpath('.//div/p/text()').extract_first()
                else:
                    val1 = head[1]
                oneproduct[head[0]] = val1

        try:
            if(oneproduct['currentPrice']==None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if(oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if(oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            try:
                if(oneproduct['Description']==None or oneproduct['Description']==""):
                    oneproduct['Description']=response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract_first()
            except:
                oneproduct['Description'] == ""
        except:
            oneproduct['Description'] == ""


        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        img_urls = []
        try:
            image_pre1 = response.xpath('//div[@class="css-kze88 e1rxi9tv0"]')[0]
            image_pre2 = image_pre1.xpath('.//style').extract()

            try:
                for sty in image_pre2:
                    id1 = sty.index('url(')+4
                    id2 = sty[id1:].index(')')
                    img_urls.append(sty[id1:id1+id2])
            except:
                pass
        except:
            pass
        oneproduct['image_urls'] = img_urls
        oneproduct['product_detail'] = product_details
        global COUNTER
        COUNTER+=1
        print(COUNTER)
        parse_product(oneproduct)




        yield None








# process = CrawlerProcess()
# process.crawl(ScrapperSpider)
# process.start()

