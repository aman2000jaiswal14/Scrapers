import os
import csv
import json

class Logger:
    def __init__(self,filename='filename'):
        self.filename  = filename
        self.folder = 'Logger'
        self.success_filename = 'success_'+self.filename+'.csv'
        self.failed_filename = 'failed_'+self.filename+'.csv'
        self.success_path = os.path.join(self.folder,self.success_filename)
        self.failed_path = os.path.join(self.folder,self.failed_filename)
        self.success_header = ['product_id','url','other_info']
        self.failed_header = ['Error_id','Error_info','product_id','url','other_info']

        try:
            if (not os.path.exists(self.folder)):
                os.mkdir(self.folder)
            if(not os.path.exists(self.success_path)):
                with open(self.success_path,'w',encoding='utf-8',newline='') as csv_file:
                    writer = csv.writer(csv_file)
                    writer.writerow(self.success_header)
            else:
                if(os.path.getsize(self.success_path)==0):
                    with open(self.success_path, 'w', encoding='utf-8', newline='') as csv_file:
                        writer = csv.writer(csv_file)
                        writer.writerow(self.success_header)

            if(not os.path.exists(self.failed_path)):
                with open(self.failed_path,'w',encoding='utf-8',newline='') as csv_file:
                    writer = csv.writer(csv_file)
                    writer.writerow(self.failed_header)
            else:
                if(os.path.getsize(self.failed_path) == 0):
                    with open(self.failed_path, 'w', encoding='utf-8', newline='') as csv_file:
                        writer = csv.writer(csv_file)
                        writer.writerow(self.failed_header)
        except Exception as e:
            print("LOGGER FAILED TO CREATE FILE DATA: ", e)


    def write_log(self,row,success = True):
        if(success):
            filepath = self.success_path
        else:
            filepath = self.failed_path
        try:
            with open(filepath,'a',newline='') as csv_file:
                writer = csv.writer(csv_file)
                writer.writerow(row)
        except Exception as e:
            print("LOGGER FAILED TO LOG DATA: ",e)

