import scrapy
import json
import csv
from scrapy.crawler import CrawlerProcess
from write_data import WriteData
from logger import Logger
####################################################
'''
PagesCount = 200
BASE = 'https://www.nykaafashion.com'
PROD_API_URL = 'https://www.nykaafashion.com/rest/appapi/V2/products?product_ids={}'
SEPERATOR = ' ||| '

FILTER = ['&price_filter=400-800']

FILENAME = 'Nykaa_Men_TopWear'

COUNTER = 0


wd = WriteData(FILENAME)
logwriter = Logger(FILENAME)

def parse_info(prod):
    data = {}

    try:
        data['category'] = prod['category']
    except:
        data['category'] = ""

    try:
        data['subcategory1'] = prod["subcategory1"]
    except:
        data['subcategory1'] = ""

    try:
        data['subcategory2'] = prod["subcategory2"]
    except:
        data['subcategory2'] = ""

    try:
        data['subcategory3'] = prod["subcategory3"]
    except:
        data['subcategory3'] = ""

    try:
        data['brand'] = prod["brand"]
    except:
        data['brand'] = ""

    try:
        data['title'] = prod['title']
    except:
        data['title'] = ""
    try:
        data['description'] = prod['Description']
    except:
        data['description'] = ""

    try:
        data['product_detail'] = json.dumps(prod['product_detail'])
    except:
        data['product_detail'] = []

    try:
        data['ManufacturedBy'] = prod["Name of Manufacturer/ Packer/ Importer"]
    except:
        data['ManufacturedBy'] = ""

    try:
        data['AddressOfManufacturer'] = prod["Address of Manufacturer/ Packer/ Importer"]
    except:
        data['AddressOfManufacturer'] = ""

    try:
        data['CountryOfOrigin'] = prod["Country of Origin"]
    except:
        data['CountryOfOrigin'] = ""

    try:
        data['Wash_Care'] = prod["Care Instructions"]
    except:
        data['Wash_Care'] = ""

    try:
        data['importedBy'] = prod["Sold By"]
    except:
        data['importedBy'] = ""

    try:
        data['currentPrice'] = prod["currentPrice"]
    except:
        data['currentPrice'] = ""

    try:
        data['orginalPrice'] = prod["originalPrice"]
    except:
        data['orginalPrice'] = ""


    try:
        data['discount'] = prod["discount"]
    except:
        data['discount'] = ""


    try:
        data['image_urls'] = prod["image_urls"]
    except:
        data['image_urls'] = ''


    try:
        data['url'] = prod['url']
    except:
        data['url'] = ""

    try:
        data['sizetag'] = prod["sizetag"]
    except:
        data['sizetag'] = ""

    try:
        data['Return_and_Exchange_Policy'] = prod["Return and Exchange Policy"]
    except:
        data['Return_and_Exchange_Policy'] = ""


    try:
        data['PackContains'] = prod["Pack Contains"]
    except:
        data['PackContains'] = ""

    try:
        data['product_id'] = prod["product_id"]
    except:
        data['product_id'] = ""

    try:
        data['category_ids'] = prod["category_ids"]
    except:
        data['category_ids'] = ""

    try:
        data['available_colors'] = prod['available_colors']
    except:
        data['available_colors'] = []

    try:
        data['Description2'] = prod['Description2']
    except:
        data['Description2'] = ''
    wd.writedata(data)
    logwriter.write_log([data['product_id'],data['url'],''])




class ScrapperSpider1(scrapy.Spider):
    name = 'scrapper1'
    category = 'WesternWear'
    # base_url  = 'https://www.nykaafashion.com/westernwear/shirts-tops-and-crop-tops/c/4497?p={}'
    # base_url = 'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4497&PageSize=50&sort=popularity&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3'
    # base_url = 'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4497&PageSize=50&currentPage=1100'
    # base_url = 'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4497&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ["https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=5&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                        "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4497&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                        "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6492&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                        "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6264&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                        "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=155&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                        "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE",
                        "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3&PageSize=50&sort=popularity{}&category_filter=7&pants_jeans_shorts_type_filter=1860&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                        "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4542&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                        "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=159&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                         "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7623&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE",
                          "https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=5262&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE" ]
        self.filters = [['&price_filter=360-2500','&price_filter=2501-324999'],
                        ['&price_filter=175-850','&price_filter=851-1500','&price_filter=1501-83999'],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        ['']]
        self.subcat = ['Dresses','Tops','T-shirts','Jeans and leggings','Jumpsuits',
                       'Bottoms','Shorts','Co-ord Sets','Skirts','Shirts','Jackets']

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = 'Women'

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)

    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] = response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] = response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] = response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath(
                '//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if (oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath(
                    '//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if (oneproduct['title'] == None or oneproduct['title'] == ''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if (len(head) > 2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if (len(head) > 2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript + SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description = response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if (len(more_description) > 0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; ' + more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,
                                 meta={'oneproduct': oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)

    def goto_prod_api(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if (oneproduct['brand'] == None or oneproduct['brand'] == ''):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]
        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct

class ScrapperSpider2(scrapy.Spider):
    name = 'scrapper2'
    category = 'IndianWear'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=69&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7630&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=662&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4543&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=652&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=10&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=164&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=647&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3907&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=156&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6498&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=5040&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7555&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE'  ]

        self.filters = [['&price_filter=360-2500','&price_filter=2501-299900'],
                        [''],
                        ['&price_filter=119-950','&price_filter=951-250900'],
                        [''],
                        [''],
                        ['&price_filter=403-2200','&price_filter=2201-220000'],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        ['']]
        self.subcat = ['Suit Sets', 'Tops and Tunics', 'Kurtis', 'Ethnic Dresses', 'Lehengas', 'Sarees', 'Blouses',
                       'Dupattas', 'Bottoms', 'Palazzos', 'Ethnic Skirts', 'Ethnic Jackets', 'Dress Material']

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = 'Women'

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)

    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] = response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] = response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] = response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath(
                '//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if (oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath(
                    '//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if (oneproduct['title'] == None or oneproduct['title'] == ''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if (len(head) > 2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if (len(head) > 2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript + SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description = response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if (len(more_description) > 0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; ' + more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,
                                 meta={'oneproduct': oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)

    def goto_prod_api(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if (oneproduct['brand'] == None or oneproduct['brand'] == ''):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]
        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct

class ScrapperSpider3(scrapy.Spider):
    name = 'scrapper3'
    category = 'Lingerie'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3947&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3986&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3975&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3997&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4015&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3998&PageSize=50&sort=popularity{}&category_filter=4009&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4006&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4007&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4008&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4011&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE'
                          ]

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        ['']]
        self.subcat = ['Bra','Sleepwear','Underwear','Loungewear','Activewear','Shapewear',
                       'Bra and Underwear Sets','Lingerie Accessories','Slips and Camisoles','Swimwear']

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = 'Women'

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct



class ScrapperSpider4(scrapy.Spider):
    name = 'scrapper4'
    category = 'Bags'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=669&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=91&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=407&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=90&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3685&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3689&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=92&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=1955&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3687&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3686&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3944&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=9&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''] ]

        self.subcat = ['Handbags','Sling and Cross Bags','Tote bags','Clutches','Satchels','Wallets',
                       'Batuas and Potlis','Backpacks','Laptop and Card Cases','Belt Bags','Pouches','Luggage and Travel Bags']

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = 'Bags'

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct


class ScrapperSpider5(scrapy.Spider):
    name = 'scrapper5'
    category = 'Shoes'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3928&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3523&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3521&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3494&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3529&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3522&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4668&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3530&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3531&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3532&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3533&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3916&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''] ]

        self.subcat = ["Sneakers","Heels","Flats","Flipflops","Wedges","Sandals",
                        "Kolhapuris","Boots","Bellies","Juttis","Loafers","Mules"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = 'Shoes'

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct


class ScrapperSpider6(scrapy.Spider):
    name = 'scrapper6'
    supercategory = 'Jewellery'
    category = 'Jewellery'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=78&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4540&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=88&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=79&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=394&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=5187&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=666&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=724&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=3969&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=5197&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7725&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=8407&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7717&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']

        self.filters = [['&price_filter=119-500','&price_filter=501-1100','&price_filter=1101-33718'],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        ['']]

        self.subcat = ["Earrings","Jewellery sets","Necklaces","Bracelets and Bangles","Rings","Hair Accessories",
                        "Anklets","Maangtika","Nose Rings","Mangalsutras","Mask Chains","Charms","Gifting"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct


class ScrapperSpider7(scrapy.Spider):
    name = 'scrapper7'
    supercategory = 'Accessories'
    category = 'Accessories'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4641&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4677&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6028&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4528&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=5187&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7218&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4898&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4897PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=4895&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7682&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=5769&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        ['']]

        self.subcat = ["Watches","Eyewear and Sunglasses","Masks","Belts","Hair Accessories",
                        "Socks","Stoles","Scarves and Mufflers","Shawls","Gloves","Hats and Caps"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct


class ScrapperSpider8(scrapy.Spider):
    name = 'scrapper8'
    supercategory = 'Kids'
    category = 'Boys'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6283&PageSize=50&sort=popularity{}{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6267&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6320&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6285&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6288&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6304&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&gender_filter=5199&category_filter=6291&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6287&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&gender_filter=5199&category_filter=6341_6338_6335_6340_6339_6336&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&gender_filter=5199&category_filter=6760_6375&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&category_filter=6332_6330&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6298&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6382&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6028&PageSize=50&sort=popularity{}&gender_filter=5199&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']
        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        ['']]

        self.subcat = ["Bodysuits and Rompers","Indianwear","Winterwear","T-shirts","Shirts",
                        "Shorts","Jeans","Sets","Footwear","Sleepwear","Innerwear","Athleisure",
                       "Toys","Masks"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct



class ScrapperSpider9(scrapy.Spider):
    name = 'scrapper9'
    supercategory = 'Kids'
    category = 'Girls'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6283&PageSize=50&sort=popularity{}&gender_filter=5198&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6267&PageSize=50&sort=popularity{}&gender_filter=5198&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6320&PageSize=50&sort=popularity{}&gender_filter=5198&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6284&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6285&PageSize=50&sort=popularity{}&gender_filter=5198&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6286&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6287&PageSize=50&sort=popularity{}&gender_filter=5198&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&gender_filter=5198&category_filter=6297&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6291&PageSize=50&sort=popularity{}&gender_filter=5198&category_filter=6291&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&gender_filter=5198&category_filter=6341_6338_6335_6340_6337_6339_6336&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&gender_filter=5198&category_filter=6375_6760&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&gender_filter=5198&category_filter=6332&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&category_filter=6346&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6382&PageSize=50&sort=popularity{}&gender_filter=5198&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6028&PageSize=50&sort=popularity{}&gender_filter=5198&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        ['']]

        self.subcat = ["Bodysuits and Rompers","Indianwear","Winterwear","Dresses","T-shirts","Tops",
                            "Sets","Bottoms","Jeans and Leggings","Footwear","Sleepwear",
                            "Innerwear","Hair Accessories","Toys","Masks"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct


class ScrapperSpider10(scrapy.Spider):
    name = 'scrapper10'
    supercategory = 'Kids'
    category = 'Infants'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6283&PageSize=50&sort=popularity{}&size_filter=5204_4752_4753_4796_4754_4795_4755_4757&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6285&PageSize=50&sort=popularity{}&size_filter=5126_4753_4752_4760_4754_4796_545_3534_4795_5124_4755_4757_5125_4759_5204_3265_2870_546_855_3365_3292_1279&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&category_filter=6297_6291_6301_6304_6300&size_filter=5126_4753_4752_4760_2869_3275_816_2431_2430_2429_4754_4790_4796_545_3534_2427_1278_4795_2426_5124_5125_4759_5204_3265_4755_4979_4757_2428_2870_642_3291_546_855_3535_3365_3292_2596_3581_3536_1279_3477&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6284&PageSize=50&sort=popularity{}&size_filter=2427_2428_3365_2869_2426_2870_642_545_546_855_1279_5126_4753_4752_4760_4790_4796_4754_3534_4795_5124_5125_4759_3265_4755_4979_4757_3535_3292_3581_3536&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&size_filter=2426_3477_4760_5126_5125_5204_5124_5122_4790_4752_4759_5205_4753_4796_4754_4795_4755_4979_4757_5121_3365_2869_2870_642_545_546_855_1278_1279_2596_3265_3275_3292_3291_3534_2431_816_2430_3535_3581_3536&category_filter=6375_6760&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6351&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6362&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6363&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6376&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6382&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6266&PageSize=50&sort=popularity{}&size_filter=4752_4790_4754_4759_4760&pack_size_filter=1354_1353_4253&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']
        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''] ]

        self.subcat = ["Bodysuits and Rompers","Tops","Bottoms","Dresses","Sleepwear and Accessories",
                        "Feeding","Cloth Diapers","Booties and Socks","Home","Toys","Value Packs"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct


class ScrapperSpider11(scrapy.Spider):
    name = 'scrapper11'
    supercategory = 'Men'
    category = 'TopWear'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6825&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6826&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6827&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6828&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6829&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6830&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6831&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6832&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7005&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7006&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']


        self.filters = [['&price_filter=150-758','&price_filter=759-6999'],
                        ['&price_filter=449-1100','&price_filter=1101-2000','&price_filter=2001-14750'],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''] ]

        self.subcat = ["T-shirts","Casual Shirts","Polo T-shirts","Formal Shirts","Jackets",
                        "Sweaters","Hoodies","Sweatshirts","Blazers and Coats","Suits"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct


class ScrapperSpider12(scrapy.Spider):
    name = 'scrapper12'
    supercategory = 'Men'
    category = 'BottomWear'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6835&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6836&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6837&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6838&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6840&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''] ]

        self.subcat = ["Jeans","Casual Trousers","Formal Trousers","Chinos","Shorts"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct



class ScrapperSpider13(scrapy.Spider):
    name = 'scrapper13'
    supercategory = 'Men'
    category = 'FootWear'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6858&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6859&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6861&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6863&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6864&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6865&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=7095&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6981&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6862&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE']

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        ['']]

        self.subcat = ["Casual Shoes","Formal Shoes","Flip Flops","Sandals",
                        "Sneakers","Sports Shoes","Clogs","Kolhapuris","Sliders"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct


class ScrapperSpider14(scrapy.Spider):
    name = 'scrapper14'
    supercategory = 'Men'
    category = 'Athleisure'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6891&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6839&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=MSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6832&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6893&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6892&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE']


        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        ['']]

        self.subcat = ["Joggers","Trackpants","Sweatshirts",
                        "Sports Shorts","Tracksuits"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct



class ScrapperSpider15(scrapy.Spider):
    name = 'scrapper15'
    supercategory = 'Men'
    category = 'Accessories'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
    }

    def start_requests(self):
        url = ''
        self.base_urls = ['https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6875&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6882&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6883&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6881&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6867&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6886&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6885&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6884&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6880&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE',
                          'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=6887&PageSize=50&sort=popularity{}&currentPage={}&filter_format=v2&currency=INR&country_code=IN&apiVersion=3&deviceType=WEBSITE']

        self.filters = [[''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''],
                        [''] ]


        self.subcat = ["Watches","Belts","Ties Cufflinks and Pocket Squares","Wallets","Bags and Backpacks",
                        "Socks","Caps","Mufflers and Gloves","Sunglasses","Stationary"]

        for base_id in range(len(self.base_urls)):
            self.base_url = self.base_urls[base_id]
            FILTER = self.filters[base_id]

            for filter in FILTER:
                try:
                    for i in range(1,PagesCount+1):
                        try:
                            print('filter : ',filter,'  PageNo. :  ',i,'  Base_id :  ',base_id)
                            url = self.base_url.format(filter,i)
                            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse, meta = {'Base_id':base_id})
                        except Exception as e:
                            log  = ['1',e,'',url,'PageCount : {}   Filter :{}'.format(i,filter)]
                            logwriter.write_log(log,success=False)
                except Exception as e:
                    log = ['2', e, '', url, 'Filter :{}'.format( filter)]
                    logwriter.write_log(log, success=False)

    def parse(self, response):
        res_url = response.url
        try:

            Base_id = response.meta['Base_id']
            response = json.loads(response.text)
            products = response['response']['products']

            for prod in products:
                try:
                    try:
                        prod_url = BASE+prod['actionUrl']
                    except Exception as e:
                        prod_url = 'empty'
                    oneproduct = {}
                    oneproduct['product_id'] = prod['id']
                    oneproduct['subcategory2'] = self.subcat[Base_id]
                    oneproduct['subcategory1'] = self.category
                    oneproduct['category'] = self.supercategory

                    yield scrapy.Request(url =prod_url,headers=self.headers,callback=self.goto_prod,meta = {'oneproduct':oneproduct})


                except Exception as e:
                    log = ['3', e, '', prod_url, 'baseid : {} ||| response_url : {}'.format(Base_id,res_url)]
                    logwriter.write_log(log, success=False)
        except Exception as e:
            log = ['4', e, '', '', '']
            logwriter.write_log(log, success=False)
    def goto_prod(self, response):
        oneproduct = response.meta['oneproduct']
        try:
            oneproduct['subcategory3'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct['brand'] = response.xpath('//a[@class="css-1rnkj6a e1vt4n323"]/text()').extract_first()
            oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n322"]/text()').extract_first()
            oneproduct["currentPrice"] =  response.xpath('//span[@class=" css-nt79bs e4picg41"]/text()').extract_first()
            oneproduct["discount"] = response.xpath('//span[@class="css-n9ao2b e4picg45"]/text()').extract_first()
            oneproduct["originalPrice"] =  response.xpath('//span[@class=" css-43auj5 e4picg42"]/text()').extract_first()
            oneproduct["sizetag"] = response.xpath('//button[@class="css-8h3q67 e15xcsrl0"]/text()').extract()
            oneproduct["url"] =  response.url
            prod_detail_key = response.xpath('//div[@class="attribute-key"]/text()').extract()
            prod_detail_val = response.xpath('//div[@class="attribute-value"]/text()').extract()
            product_details = {i: j for i, j in zip(prod_detail_key, prod_detail_val)}
            oneproduct['product_detail'] = product_details
        except Exception as e:
            log = ['5', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            oneproduct['available_colors'] = response.xpath('//div[@class="css-1wdjgh5 eufev3p0"]/button/@title').extract()
        except:
            oneproduct['available_colors'] = []
        try:
            if(oneproduct['currentPrice'] == None):
                oneproduct['currentPrice'] = response.xpath('//span[@class="css-nt79bs e4picg41"]/text()').extract_first()
                if (oneproduct['originalPrice'] == None):
                    oneproduct['originalPrice'] = oneproduct['currentPrice']
                if (oneproduct['discount'] == None):
                    oneproduct['discount'] = '0'
        except:
            pass

        try:
            if(oneproduct['title']==None or oneproduct['title']==''):
                oneproduct['title'] = ''
                oneproduct['title'] = response.xpath('//div[@class="css-oumgbf e1vt4n324"]/text()').extract_first()
                oneproduct['subcategory3'] = oneproduct['title']
        except:
            pass

        other_details1 = response.xpath('//div[@class="css-yi7vzh ez6ebqp1"]')
        other_details2 = response.xpath('//div[@class="css-12t4ws1 ez6ebqp1"]')
        try:
            for res in other_details1:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["",""]

                if(head[0]!="",head[0]!="Product Details" or head[0]!="Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif(len(head)==1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['6', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            for res in other_details2:
                try:
                    head = res.xpath('.//div/text()').extract()
                except:
                    head = ["", ""]

                if (head[0] != "", head[0] != "Product Details" or head[0] != "Size & Fit"):
                    if(len(head)>2):
                        val1 = '  '.join(head[1:])
                    elif (len(head) == 1):
                        val1 = res.xpath('.//div/p/text()').extract_first()
                    else:
                        val1 = head[1]
                    oneproduct[head[0]] = val1
        except Exception as e:
            log = ['7', e, '', response.url, '']
            logwriter.write_log(log, success=False)
        try:
            if (oneproduct['Description'] == None):
                oneproduct['Description'] = ""
        except:
            oneproduct['Description'] = ""
        try:
            try:
                descript = oneproduct['Description']
                descript1 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/p/text()').extract()
                descript2 = response.xpath('//div[@class="css-3k9fjh ez6ebqp3"]/ul/li/text()').extract()
                descript = descript +  SEPERATOR.join(descript1) + SEPERATOR.join(descript2)

                oneproduct['Description'] = descript

            except:
                pass
        except:
            pass

        try:
            more_description =response.xpath('//ul[@class="product-details__list"]/li/text()').extract()
            if(len(more_description)>0):
                more_description = ', '.join(more_description)
                oneproduct['Description'] = oneproduct['Description'] + ' ; '+more_description
        except:
            pass

        prod_api = PROD_API_URL.format(oneproduct['product_id'])
        try:
            yield scrapy.Request(url=prod_api, headers=self.headers, callback=self.goto_prod_api,meta = {'oneproduct':oneproduct})
        except Exception as e:
            log = ['8', e, oneproduct['product_id'], prod_api, 'prod_url : {}'.format(response.url)]
            logwriter.write_log(log, success=False)


    def goto_prod_api(self,response):
        oneproduct = response.meta['oneproduct']
        try:
            response = json.loads(response.text)
            cat_ids = str(response['result']['products'][0]['category_ids'])
            cat_ids = cat_ids.split(',')
            cat_ids = SEPERATOR.join(cat_ids)
            oneproduct['category_ids'] = cat_ids
            all_imgs = response['result']['products'][0]['media']
            img_list = []
            for all_img in all_imgs:
                img_list.append(all_img['url'])

            oneproduct['image_urls'] = SEPERATOR.join(img_list)
        except Exception as e:
            log = ['9', e, '', response.url, 'APIURL']
            logwriter.write_log(log, success=False)

        try:
            oneproduct['Description2'] = response['result']['products'][0]['description']
            if(oneproduct['brand']==None or oneproduct['brand']=='' ):
                oneproduct['brand'] = response['result']['products'][0]['brand_name'][0]

        except:
            oneproduct['brand'] = ''
        parse_info(oneproduct)
        global COUNTER
        COUNTER += 1
        print(COUNTER)
        return oneproduct

process = CrawlerProcess()
process.crawl(ScrapperSpider11)
process.start()
'''